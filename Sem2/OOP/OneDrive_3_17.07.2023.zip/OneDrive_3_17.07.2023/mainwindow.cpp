#include "mainwindow.h"
#include "ui_mainwindow.h"

#include <QGridLayout>
#include <QDebug>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)

{
    m_lineEdit = new QLineEdit{this};
    m_numbersList = new QListWidget{this};
    m_addNumberBtn = new QPushButton{"Add", this};
    QPushButton* clearListBtn {new QPushButton{"Clear", this}};

    QGridLayout* layout{new QGridLayout{}};
    layout->addWidget(m_lineEdit, 0, 1);
    layout->addWidget(m_addNumberBtn, 1, 1);
    layout->addWidget(clearListBtn, 2, 1);

    layout->addWidget(m_numbersList, 0, 0, 3, 1);

    QWidget* w {new QWidget{this}};
    w->setLayout(layout);
    this->setCentralWidget(w);

    // communication
    // - sender
    // - receiver
    connect(m_addNumberBtn, &QPushButton::clicked,  // -> sender part: sender object m_addNumberBtn,
            // &QPushButton::clicked -> pointer to the clicked signal
            this, // receiver object
            &MainWindow::onButtonPressed // pointer to the slot
            );


    connect(clearListBtn, &QPushButton::clicked,
            this,
            // lambda function
            // [] -> capture clause, = -> captures everything by value, &  -> captures everything by reference
            // () -> params of the lambda
            // {...} -> body of the lambda
            [this]() mutable{

        //qDebug()<<"clear list";
        this->m_numbersList->clear();
        emit this->lambdaOver();
    }
    );

    connect(this,
            &MainWindow::lambdaOver,
            this,
            [](){

        qDebug()<<"after lambda is over";
    }
    );

    //
}

MainWindow::~MainWindow()
{

}

void MainWindow::onButtonPressed()
{
    //    qDebug()<<"button pressed: "<<m_lineEdit->text();
    m_numbersList->addItem(m_lineEdit->text()); // adds an element at the end of the list

}

