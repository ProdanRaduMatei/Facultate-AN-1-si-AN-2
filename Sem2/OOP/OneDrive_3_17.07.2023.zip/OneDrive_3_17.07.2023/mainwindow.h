#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QLineEdit>
#include <QPushButton>
#include <QListWidget>

class MainWindow : public QMainWindow // (1) inherit from qobject
{
    // (2) Q_OBJECT
    Q_OBJECT

public:
    MainWindow(QWidget *parent = nullptr);
    ~MainWindow();

public slots:
    void onButtonPressed();

signals:
    void lambdaOver(); // signals don't need a definition

private:
    QLineEdit* m_lineEdit;
    QListWidget* m_numbersList;
    QPushButton* m_addNumberBtn;
};
#endif // MAINWINDOW_H
