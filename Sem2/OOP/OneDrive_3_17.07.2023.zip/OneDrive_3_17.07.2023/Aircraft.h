#pragma once
#include <string>
#include <vector>
#include <ostream>
using namespace std;

enum class ActivityType {
	PUBLIC_TRANSPORTATION, 
	MEDICAL,
	LEISURE, 
	MILITARY
};

class Aircraft
{
public:
	// constrctor cu param
	Aircraft(int i, std::string model, int maxAlt);

	int getID() const;
	void setID(int id);

	virtual std::string what() const {return "aircraft"; }
	friend ostream& operator<<(ostream& os, const Aircraft& a);

public:
	// abstract method - pure virtual
	virtual std::vector<ActivityType> suitableFor() = 0; // =0 pure virtual (is abstract function)

protected:
	int id;
	std::string model;
	int maxAltitude;
};

//A helicopter:
// has the following additional characteristic : isPrivate, specifying whether the helicopter belongs to the state or to a private entity.
// is suitable for activities like : military, medical emergencies, public transportationand leisure time(only if it is private).
// can reach a maximum altitude of 12 km.
class Helicopter : public Aircraft{
public:
	Helicopter(int i, std::string model, bool pr);

	bool getIsPrivate() const;
	void setIsPrivate(bool pr);
	std::string what() const { return "helicopter"; }
	std::vector<ActivityType> suitableFor() override;
private:
	bool isPrivate;
};

// A hot air balloon:
// � has the following additional characteristics : weight limit, specifying the maximum weight limit for the balloon.
// � is suitable for activities like : leisure time.
// � can reach a maximum altitude of 21 km.
class HotAirBallon : public Aircraft {
public:
	HotAirBallon(int i, std::string model, int wl);
	std::string what() const { return "hotair ballon"; }
	std::vector<ActivityType> suitableFor() override;
private:
	int weightLimit;
	
};