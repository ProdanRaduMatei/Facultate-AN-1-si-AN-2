// Seminar4.cpp : This file contains the 'main' function. Program execution begins and ends there.
//
#include <map>
#include <iostream>
#include "Aircraft.h"
int main()
{
    // Aircraft aircraft; -> NOOOOOOOOOOOOOOOO is abstract
    Helicopter h{1, "e1", true};
    Helicopter h1{2, "e1", false};
    Helicopter* h2{ new Helicopter{3, "e1", true} };
    
    HotAirBallon hb{224, "h1", 100};
    HotAirBallon hb1{ 200, "h2", 100 };
    
  //  Aircraft& aircraft = hb1; //upcasting- IMPLICT

    // TO REMEMBER!!!!
    // 1. non value types (pointers || references) to the base class to store derived class objects
    // pointer la clasa de baza
    // 2. virtual methods
    std::vector<Aircraft*> aircrafts;
    aircrafts.push_back(&h1); // h1 is a Helicopter -> we need a Aircraft*
                               // &h1 - the address of h1(a pointer to h1) -> Helicopter*
                                // Helicopter* to Aircraft* -> IMPLICT upcasting 
    aircrafts.push_back(&h);
    aircrafts.push_back(h2);
    aircrafts.push_back(&hb);
    aircrafts.push_back(&hb1);

    for (Aircraft* a : aircrafts) {
        //cout << *a;
        // ostream& operator<<(ostream & os, const Aircraft & a);
        operator<<(cout, *a);
        //std::cout << a->getID() << " is a " << a->what()<<std::endl;
    }

    // non value types (pointers || references) to the base class to store derived class objects
    // pointer la clasa de baza
    Aircraft* a = &h;
    Aircraft& rHB = hb;
    
    std::vector<ActivityType> activities = a->suitableFor();
    //for actvivity in activities:
    std::map<ActivityType, std::string> at2String; /// store the string representation of an actitivty type
        // key: ActivityType::PUBLIC_TRANSPORTATION, val "public_transport"
        // key: ActivityType::MEDICAL, val "medical"
    at2String[ActivityType::PUBLIC_TRANSPORTATION] = "public_transportation";
    at2String[ActivityType::MEDICAL] = "medical";
    at2String[ActivityType::MILITARY] = "militray";
    at2String[ActivityType::LEISURE] = "leisure";

    for (ActivityType at : activities) {
        std::cout << at2String[at]<<" ";
    }
    std::cout << std::endl;

    std::cout << "Hello World!\n";
    delete h2;
    return 0;
}

