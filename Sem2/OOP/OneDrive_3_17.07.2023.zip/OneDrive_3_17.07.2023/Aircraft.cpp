#include "Aircraft.h"
#include <iomanip>
Aircraft::Aircraft(int i, std::string m, int maxAlt) : id( i ),
model{m},
maxAltitude{maxAlt} {}


int Aircraft::getID() const {
	return this->id;
}

void Aircraft::setID(int id) {
	this->id = id;
}

ostream& operator<<(ostream& os, const Aircraft& a) {
	os << setw(5) <<left<< a.id << "| model" << setw(10) << a.model << " | type "<<setw(7) << a.what() << endl;
	return os;
 }


/// helicopter

Helicopter::Helicopter(int i, std::string model, bool pr) 
	: Aircraft{ i, model, 12}, isPrivate{pr} {

}

bool Helicopter::getIsPrivate() const {
	return this->isPrivate;
}
void Helicopter::setIsPrivate(bool pr) {
	this->isPrivate = pr;
}

std::vector<ActivityType> Helicopter::suitableFor() {
	//is suitable for activities like: military, medical emergencies, public transportation and leisure time (only if it is private).
	/*PUBLIC_TRANSPORTATION,
		MEDICAL,
		LEISURE,
		MILITARY*/
	std::vector<ActivityType> res; // vector gol  res: []
	res.push_back(ActivityType::MILITARY);  // res: [ActivityType::MILITARY]
	res.push_back(ActivityType::MEDICAL); //res: [ActivityType::MILITARY, ActivityType::MEDICAL]
	res.push_back(ActivityType::PUBLIC_TRANSPORTATION);//res: [ActivityType::MILITARY, ActivityType::MEDICAL, ActivityType::PUBLIC_TRANSPORTATION]

	if (this->isPrivate)
		res.push_back(ActivityType::LEISURE);

	return res;
}


// HOT AIR BALLON

HotAirBallon::HotAirBallon(int i, std::string model, int wl):
	Aircraft{ i, model, 21 }, weightLimit{wl}
{}

std::vector<ActivityType> HotAirBallon::suitableFor() {
	//std::vector<ActivityType> res{ActivityType::LEISURE};
	std::vector<ActivityType> res;
	res.push_back(ActivityType::LEISURE);
	return res;
}