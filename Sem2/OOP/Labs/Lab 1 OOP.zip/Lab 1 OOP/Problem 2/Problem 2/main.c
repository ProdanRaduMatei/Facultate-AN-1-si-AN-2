#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>

// Alice forgot her cards PIN code.She remembers that her PIN code had 4 digits, all the digits were distinct and in decreasing order, and that the sum of these digits was 24.
// This C program that prints, on different lines, all the PIN codes which fulfill these constraints.

int main()
{
    int A, B, C, D;
    for (A = 9; A >= 3; A--)
        for (B = A - 1; B >= 2; B--)
            for (C = B - 1; C >= 1; C--) {
                D = 24 - A - B - C;
                    if (D < C && D >= 0)
                        printf("%d %d %d %d\n", A, B, C, D);
            }
    return 0;
}
