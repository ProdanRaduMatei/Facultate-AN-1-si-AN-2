#ifndef TESTS_H
#define TESTS_H

#include <stdbool.h>

#define ENABLE_TESTS 1
void run_tests(bool verbose);
#endif
