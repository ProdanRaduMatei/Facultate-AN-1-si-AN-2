#include <iostream>
#include <fstream>
#include <iomanip>
#include <cstring>

class Point {
public:
    int x;
    int y;
    Point(int x, int y): x(x), y(y) {}
};

class Image {
private:
    int* pixels;
    int width;
    int height;
    
public:
    // Constructors and Destructor
    Image(): pixels(nullptr), width(0), height(0) {}
    Image(int width, int height): pixels(new int[width*height]), width(width), height(height) {}
    Image(const Image& other): pixels(new int[other.width*other.height]), width(other.width), height(other.height) {
        std::memcpy(pixels, other.pixels, sizeof(int)*width*height);
    }
    ~Image() {
        delete[] pixels;
    }
    
    // Copy assignment operator
    Image& operator=(const Image& other) {
        if (this == &other)
            return *this;
        delete[] pixels;
        pixels = new int[other.width*other.height];
        width = other.width;
        height = other.height;
        std::memcpy(pixels, other.pixels, sizeof(int)*width*height);
        return *this;
    }
    
    // Getters
    int getWidth() const {
        return width;
    }
    int getHeight() const {
        return height;
    }
    std::string getSize() const {
        return std::to_string(width) + "x" + std::to_string(height);
    }
    
    // Load and Save
    bool loadFromFile(const std::string& filename) {
        std::ifstream file(filename, std::ios::binary);
        if (!file.is_open())
            return false;
        std::string magicNumber;
        std::getline(file, magicNumber);
        if (magicNumber != "P5")
            return false;
        int maxVal;
        file >> width >> height >> maxVal;
        file.get(); // consume the newline character
        delete[] pixels;
        pixels = new int[width*height];
        file.read(reinterpret_cast<char*>(pixels), width*height);
        file.close();
        return true;
    }
    bool saveToFile(const std::string& filename) const {
        std::ofstream file(filename, std::ios::binary);
        if (!file.is_open())
            return false;
        file << "P5\n" << width << " " << height << "\n255\n";
        file.write(reinterpret_cast<const char*>(pixels), width*height);
        file.close();
        return true;
    }
    
    // Operators
    friend std::ostream& operator<<(std::ostream& os, const Image& image) {
        for (int y = 0; y < image.height; y++) {
            for (int x = 0; x < image.width; x++)
                os << std::setw(3) << image.pixels[y*image.width + x] << " ";
            os << "\n";
        }
        return os;
    }
    Image operator+(const Image& other) const {
        if (width != other.width || height != other.height)
            throw std::invalid_argument("Image dimensions do not match");
        Image result(width, height);
        for (int i = 0; i < width*height; i++)
            result.pixels[i] = pixels[i] + other.pixels[i];
        return result;
    }
    Image operator-(const Image& other) const {
        if (width != other.width || height != other.height)
            throw std::invalid_argument("Image dimensions do not match");
        Image result(width, height);
        for (int i = 0; i < width*height; i++)
            result.pixels[i] = pixels[i] - other.pixels[i];
        return result;
    }
    
    Image operator*(const Image& other) const {
        if (width != other.width || height != other.height)
            throw std::invalid_argument("Image dimensions do not match");
        Image result(width, height);
        for (int i = 0; i < width*height; i++)
            result.pixels[i] = pixels[i] * other.pixels[i];
        return result;
    }
    
    Image operator+(int scalar) const {
        Image result(width, height);
        for (int i = 0; i < width*height; i++)
            result.pixels[i] = pixels[i] + scalar;
        return result;
    }
    
    Image operator-(int scalar) const {
        Image result(width, height);
        for (int i = 0; i < width*height; i++)
            result.pixels[i] = pixels[i] - scalar;
        return result;
    }
    
    Image operator*(int scalar) const {
        Image result(width, height);
        for (int i = 0; i < width*height; i++)
            result.pixels[i] = pixels[i] * scalar;
        return result;
    }
    
    bool isEmpty() const {
        return (width == 0 || height == 0);
    }
    
    // Method to get a reference to a pixel in the image
    int& operator()(int x, int y) {
        if (x < 0 || x >= width || y < 0 || y >= height)
            throw std::out_of_range("Index out of bounds");
        return pixels[y * width + x];
    }
    
    int& operator()(const Point& p) {
        return (*this)(p.x, p.y);
    }
    
    // Method to get a pointer to a row in the image
    int* getRow(int y) {
        if (y < 0 || y >= height)
            throw std::out_of_range("Index out of bounds");
        return pixels + y * width;
    }
    
    // Method to release the memory allocated for the image
    void release() {
        delete[] pixels;
        width = 0;
        height = 0;
        pixels = nullptr;
    }
    
    // Method to get a new image containing a region of interest
    Image getROI(int x, int y, int w, int h) const {
        if (x < 0 || y < 0 || w <= 0 || h <= 0 || x + w > width || y + h > height)
            throw std::out_of_range("Invalid ROI");
        
        Image roi(w, h);
        for (int j = 0; j < h; j++) {
            std::copy(pixels + (y + j) * width + x, pixels + (y + j) * width + x + w, roi.pixels + j*w);
        }
        return roi;
    }
    
    // Static methods
    static Image zeros(int w, int h) {
        Image img(w, h);
        std::memset(img.pixels, 0, w*h*sizeof(int));
        return img;
    }
    
    static Image ones(int w, int h) {
        Image img(w, h);
        std::memset(img.pixels, 1, w*h*sizeof(int));
        return img;
    }
};
