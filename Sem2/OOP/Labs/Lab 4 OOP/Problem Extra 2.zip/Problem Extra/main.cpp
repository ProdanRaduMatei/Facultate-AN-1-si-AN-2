#include <iostream>
#include "Image.cpp" // assuming the class is defined in "Image.h"

int main() {
    // Create an image with dimensions 3x3 and fill it with zeros
    Image img(3, 3);

    // Test the loadFromFile method
    /*if (!img.loadFromFile("test.pgm")) {
        std::cerr << "Failed to load image from file.\n";
        return 1;
    }*/

    // Test the getSize method
    std::cout << "Image size: " << img.getSize() << "\n";

    // Test the operator<< method
    std::cout << img;

    // Test the copy constructor and operator=
    Image img2(img);
    Image img3 = img2;

    // Test the operator+ method
    Image img4 = img + img2;
    std::cout << img4;

    // Test the operator- method
    Image img5 = img - img2;
    std::cout << img5;

    // Test the operator* method
    Image img6 = img * img2;
    std::cout << img6;

    // Test the operator+ (scalar) method
    Image img7 = img + 100;
    std::cout << img7;

    // Test the operator- (scalar) method
    Image img8 = img - 50;
    std::cout << img8;

    // Test the operator* (scalar) method
    Image img9 = img * 2;
    std::cout << img9;

    // Test the isEmpty method
    std::cout << "img isEmpty? " << img.isEmpty() << "\n";
    Image img10;
    std::cout << "img10 isEmpty? " << img10.isEmpty() << "\n";

    // Test the operator() method
    img(0, 0) = 255;
    std::cout << img;

    // Test the saveToFile method
    if (!img.saveToFile("out.pgm")) {
        std::cerr << "Failed to save image to file.\n";
        return 1;
    }

    return 0;
}
