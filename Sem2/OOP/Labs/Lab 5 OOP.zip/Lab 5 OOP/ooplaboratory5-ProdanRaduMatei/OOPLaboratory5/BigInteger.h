#pragma once
#include<string>
#include<iostream>


class BigInteger{

public:

private:

};
