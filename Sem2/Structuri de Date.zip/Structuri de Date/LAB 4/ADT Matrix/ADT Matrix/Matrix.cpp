#include "Matrix.h"
#include <stdexcept>

// Constructor
Matrix::Matrix(int nrLines, int nrCols) {
    //WC: Theta(nrLines * nrCols)
	//BC: Theta(1)
	//AC: Theta(nrLines * nrCols)
    this->nrlines = nrLines;
    this->nrcols = nrCols;
    this->capacity = nrLines * nrCols;
    this->table = new hashTable[capacity];
    for (int i = 0; i < capacity; ++i) {
        table[i].key = -1;  // Initializing key to -1 to indicate empty slot
        table[i].next = nullptr;
    }
}

// Returns the number of lines
int Matrix::nrLines() const {
	//WC: Theta(1)
	//BC: Theta(1)
	//AC: Theta(1)
    return nrlines;
}

// Returns the number of columns
int Matrix::nrColumns() const {
	//WC: Theta(1)
	//BC: Theta(1)
	//AC: Theta(1)
    return nrcols;
}

// Returns the element at line i and column j (indexing starts from 0)
// Throws an exception if (i, j) is not a valid position in the Matrix
TElem Matrix::element(int i, int j) const {
	//WC: Theta(nrLines * nrCols)
	//BC: Theta(1)
	//AC: Theta(nrLines * nrCols)
    if (i < 0 || i >= nrlines || j < 0 || j >= nrcols)
        throw std::out_of_range("Invalid position");

    int key = i * nrcols + j;
    int index = hash(key, capacity);

    hashTable* curr = &table[index];

    // Traverse the linked list to find the element
    while (curr != nullptr) {
        if (curr->line == i && curr->column == j)
            return curr->value;
        curr = curr->next;
    }
    return NULL_TELEM;
}

// Modifies the value at line i and column j
// Returns the previous value at the position
// Throws an exception if (i, j) is not a valid position in the Matrix
TElem Matrix::modify(int i, int j, TElem e) {
	//WC: Theta(nrLines * nrCols)
	//BC: Theta(1)
	//AC: Theta(nrLines * nrCols)
    if (i < 0 || i >= nrlines || j < 0 || j >= nrcols)
        throw std::out_of_range("Invalid position");

    int key = i * nrcols + j;
    int index = hash(key, capacity);

    hashTable* curr = &table[index];
    hashTable* prev = nullptr;

    // Traverse the linked list to find the element
    while (curr != nullptr) {
        if (curr->line == i && curr->column == j) {
            TElem previousValue = curr->value;
            curr->value = e;
            return previousValue;
        }
        prev = curr;
        curr = curr->next;
    }

    // Element not found, create a new element
    hashTable* newElement = new hashTable();
    newElement->value = e;
    newElement->line = i;
    newElement->column = j;
    newElement->key = key;
    newElement->next = nullptr;

    if (prev == nullptr)
        table[index] = *newElement;
    else
        prev->next = newElement;

    return NULL_TELEM;
}

// Hash function
int Matrix::hash(int k, int capacity) const {
	//WC: Theta(1)
	//BC: Theta(1)
	//AC: Theta(1)
    return k % capacity;
}

// Resize the hashtable to double its capacity
void Matrix::resize() {
	//WC: Theta(nrLines * nrCols)
	//BC: Theta(1)
	//AC: Theta(nrLines * nrCols)
    int newCapacity = capacity * 2;
    hashTable* newTable = new hashTable[newCapacity];
    for (int i = 0; i < newCapacity; ++i) {
        newTable[i].key = -1;  // Initializing key to -1 to indicate empty slot
        newTable[i].next = nullptr;
    }

    for (int i = 0; i < capacity; ++i) {
        hashTable* curr = &table[i];

        // Traverse the linked list in the current slot
        while (curr != nullptr) {
            hashTable* next = curr->next;
            int newIndex = hash(curr->key, newCapacity);
            curr->next = &newTable[newIndex];
            newTable[newIndex] = *curr;
            curr = next;
        }
    }

    delete[] table;
    table = newTable;
    capacity = newCapacity;
}
