#include "SMIterator.h"
#include "SortedMap.h"
#include <exception>

using namespace std;

SMIterator::SMIterator(const SortedMap& m) : map(m){
    //TODO - Implementation
    current_index = -1;
}

void SMIterator::first(){
    //TODO - Implementation
    // Set current index to 0 if map is not empty
    if (map.n > 0)
        current_index = 0;
    else
        current_index = -1;
}

void SMIterator::next(){
    //TODO - Implementation
    // Increment current index if it's not at the end of the map
    if (current_index < map.n - 1)
        current_index++;
    else
        throw exception(); // Otherwise throw an exception
}

bool SMIterator::valid() const{
    //TODO - Implementation
    // Check if the current index is a valid index
    return current_index >= 0 && current_index < map.n;
}

TElem SMIterator::getCurrent() const{
    //TODO - Implementation
    // Return the element at the current index
    if (valid())
        return map.M[current_index];
    else
        throw exception(); // Otherwise throw an exception
}


