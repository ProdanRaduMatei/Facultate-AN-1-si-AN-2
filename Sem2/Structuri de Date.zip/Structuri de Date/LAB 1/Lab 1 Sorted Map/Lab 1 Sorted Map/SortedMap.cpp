#include "SMIterator.h"
#include "SortedMap.h"
#include <exception>
using namespace std;

bool Rel(TKey k1, TKey k2) {
    if (k1 <= k2)
        return true;
    return false;
}

void SortedMap::resize() {
    //BC:T(1)
    //WC:T(n)
    //AC:O(n)
    Size *= 2;
    TElem* newM = new TElem[Size];
    for (int i = 0; i < Size; i++)
        newM[i] = NULL_TPAIR;
    for (int i = 0; i < n; i++)
        newM[i] = M[i];
    delete[] M;
    M = newM;
}

SortedMap::SortedMap(Relation r) {
    //BC:T(1)
    //WC:T(1)
    //AC:T(1)
	//TODO - Implementation
    //We initialize the number of elements
    Size = 1;
    n = 0;
    M = new TElem[Size];
    for (int i = 0; i < Size; i++)
        M[i] = NULL_TPAIR;
    //We allocate memory space for a map
}

TValue SortedMap::add(TKey k, TValue v) {
    //BC:T(1)
    //WC:T(n)
    //AC:O(n)
	//TODO - Implementation
    int i = 0;
    while (i < n && M[i].first != k)
        i++;
    if (i < n) {
        TValue oldV = M[i].second;
        M[i].second = v;
        return oldV;
    }
    if (n == Size)
        resize();
    int j = n - 1;
    while (j >= 0 && M[j].first > k) {
        M[j + 1] = M[j];
        j--;
    }
    M[j + 1] = std::make_pair(k, v);
    n++;
    return NULL_TVALUE;
}

TValue SortedMap::search(TKey k) const {
    //BC:T(1)
    //WC:T(n)
    //AC:O(n)
	//TODO - Implementation
    int i = 0;
    while (i < n && M[i].first != k)
        i++;
    if (i < n)
        return M[i].second;
    return NULL_TVALUE;
}

TValue SortedMap::remove(TKey k) {
    //BC:T(n)
    //WC:T(n)
    //AC:T(n)
	//TODO - Implementation
    int i = 0;
    while (i < n && M[i].first != k)
        i++;
    if (i == n)
        return NULL_TVALUE;
    TValue oldV = M[i].second;
    for (int j = i; j < n - 1; j++)
        M[j] = M[j + 1];
    n--;
    return oldV;
}

int SortedMap::size() const {
    //BC:T(1)
    //WC:T(1)
    //AC:T(1)
	//TODO - Implementation
	return this->n;
}

bool SortedMap::isEmpty() const {
    //BC:T(1)
    //WC:T(1)
    //AC:T(1)
	//TODO - Implementation
    return (n == 0);
}

SMIterator SortedMap::iterator() const {
    //BC:T(1)
    //WC:T(1)
    //AC:T(1)
	return SMIterator(*this);
}

SortedMap::~SortedMap() {
    //BC:T(1)
    //WC:T(1)
    //AC:T(1)
	//TODO - Implementation
    delete[] M;
}
