#include "SMIterator.h"
#include "SortedMap.h"
#include <exception>

using namespace std;

SMIterator::SMIterator(const SortedMap& m) : map(m){
	//TODO - Implementation
}

void SMIterator::first(){
	//TODO - Implementation
}

void SMIterator::next(){
	//TODO - Implementation
}

bool SMIterator::valid() const{
	//TODO - Implementation
	return false;
}

TElem SMIterator::getCurrent() const{
	//TODO - Implementation
	return NULL_TPAIR;
}


