class Bag:
    def __init__(self):
        self.__elems = []
    def add(self, e):
        self.__elems.append(e)
    def search(self, e):
        return e in self.__elems
    def remove(self, e):
        return self.__elems.remove(e)
    def size(self):
        return len(self.__elems)
    def iterator(self):
        return Iterator(self)
    def nrOccurrences(self, e):
        n = 0
        for elem in self.__elems:
            if elem == e:
                n = n + 1
        return n

class Iterator:
    def __init__(self,c):
        self.__bag = c
        self.__current = 0
    def getCurrent(self):
        return self.__bag._Bag__elems[self.__current]
    def next(self):
        self.__current = self.__current+1
    def valid(self):
        return self.__current < self.__bag.size()
    def first(self):
        self.__current = 0
        
def populateIntBag(c):
    c.add(1)
    c.add(2)
    c.add(3)
    c.add(2)
    c.remove(2)
    c.add(2)
    
def printBag(c):
    it = c.iterator()
    while it.valid():
        print(it.getCurrent())
        it.next()
    print("Over. Let's print the bag content again.")
    it.first()
    while it.valid():
        print(it.getCurrent())
        it.next()
        
def main():
    b = Bag()
    populateIntBag(b)
    print("Number of occurrences for 2: ", b.nrOccurrences(2))
    printBag(b)

main()
