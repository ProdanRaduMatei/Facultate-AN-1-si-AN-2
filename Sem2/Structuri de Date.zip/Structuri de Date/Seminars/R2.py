class PairElementFrequency:
    def __init__(self,e,f):
        self.__e = e
        self.__f = f
    def setElement(self, e):
        self.__e = e
    def setFrequency(self, f):
        self.__f = f
    def getElement(self):
        return self.__e
    def getFrequency(self):
        return self.__f
    def __eq__(self, other):
        return (self.__e == other.__e)

class BagElementFrequency:

    def __init__(self):
        self.__pairs = []

    def add(self, e):
    # We distinguish two cases: the element already appears in the bag or it does 
    # not appear in the bag yet
    # If the element already appears in the bag, we have to increment its      
    # frequency   
    # If the element does not appear in the bag yet, then we add it to the 
    # bag with frequency 1 
        found = False
        for p in self.__pairs:
            if p.getElement()== e:
                p.setFrequency(p.getFrequency()+1)
                found = True
        if not(found):
            p = PairElementFrequency(e,1)
            self.__pairs.append(p)

    def search(self, e):
         for p in self.__pairs:
            if p.getElement() == e: 
                return True
         return False

    def remove(self, e):
    # We distinguish three cases: the element does not appear in the bag, the   
    # element appears only once in the bag or the element appears in the bag 
    # more than once
    # If the element does not appear in the bag, than the bag remains 
    # unmodified
    # If the element appears in the bag only once, then it will be deleted 
    # If the element appears in the bag more than once, then its frequency 
    # will be decremented
        for p in self.__pairs:
            if p.getElement() == e:
                if p.getFrequency() > 1:
                    p.setFrequency(p.getFrequency()-1)
                else:
                    self.__pairs.remove(p)
                return True
        return False

    def size(self):
        s = 0
        for p in self.__pairs:
            s = s + p.getFrequency()
        return s

    def iterator(self):
        return IteratorBagFrequency(self)

    def nrOccurrences(self, e):
        for p in self.__pairs:
            if p.getElement() == e:
                return p.getFrequency()
        return 0


class IteratorBagFrequency:
    def __init__(self, b):
        self.__bag = b
        self.__current = 0
        self.__f = 1

    def valid(self):
        return self.__current < len(self.__bag._BagElementFrequency__pairs)

    def getCurrent(self):
        return self.__bag._BagElementFrequency__pairs[self.__current].getElement()

    def next(self):
    # We distinguish two cases: the current frequency for the current element is   
    #(1) strictly less than the frequency of the current element in and bag or   
    #(2) equal to the frequency of the current element in the bag
        # If the current frequency for the current element is strictly less that 
        # the frequency of the element in the bag, then we just increment the 
        # current frequency 
        # If the current frequency of the current element is equal to the  
        # frequency of the element in the bag, then we have to pass to the next 
        # element by incrementing the current index and reinitializing the 
        # current frequency with 1 
        if self.__f < self.__bag._BagElementFrequency__pairs[self.__current].getFrequency():
           self.__f = self.__f+1
        else:
           self.__current = self.__current+1
           self.__f=1

    def first(self):
        self.__current = 0
        self.__f = 1

def populateIntBag(c):
    c.add(1)
    c.add(2)
    c.add(3)
    c.add(2)
    c.remove(2)
    c.add(2)
    
def printBag(c):
    it = c.iterator()
    while it.valid():
        print(it.getCurrent())
        it.next()
    print("Over. Let's print the bag content again.")
    it.first()
    while it.valid():
        print(it.getCurrent())
        it.next()
        
def main():
    b = BagElementFrequency()
    populateIntBag(b)
    print("Number of occurrences for 2: ", b.nrOccurrences(2))
    printBag(b)

main()
    
