#include "Matrix.h"

Matrix::Matrix(int nrLines, int nrCols) : Rows(nrLines), Columns(nrCols) {
    //WC: T(1)
    //BC: T(1)
    //AC: T(1)
    //initialize the first and last node
    first = new Node;
    last = new Node;
    first->next = last;
    last->previous = first;
    nrelements = 0;
}

int Matrix::nrLines() const {
    //WC: T(1)
    //BC: T(1)
    //AC: T(1)
    return Rows;
}

int Matrix::nrColumns() const {
    //WC: T(1)
    //BC: T(1)
    //AC: T(1)
    return Columns;
}

TElem Matrix::element(int i, int j) const {
    //WC: T(rows*cols)
    //BC: T(1)
    //AC: O(rows*cols)
    if (i < 0 || i >= Rows || j < 0 || j >= Columns) {
        throw std::out_of_range("Invalid position");
    }
    Node* currentNode = first->next;
    while (currentNode != last) {
        if (currentNode->row == i && currentNode->col == j) {
            return currentNode->v;
        }
        currentNode = currentNode->next;
    }
    return NULL_TELEM;
}

TElem Matrix::modify(int i, int j, TElem e) {
    //WC: T(rows*cols)
    //BC: T(1)
    //AC: O(rows*cols)
    if (i < 0 || i >= Rows || j < 0 || j >= Columns) {
        throw std::out_of_range("Invalid position");
    }
    Node* currentNode = first->next;
    while (currentNode != last) {
        if (currentNode->row == i && currentNode->col == j) {
            TElem oldValue = currentNode->v;
            currentNode->v = e;
            return oldValue;
        }
        currentNode = currentNode->next;
    }
    //if the element was not found, create a new node and insert it in the right position
    Node* newNode = new Node;
    newNode->row = i;
    newNode->col = j;
    newNode->v = e;
    newNode->next = last;
    newNode->previous = last->previous;
    last->previous->next = newNode;
    last->previous = newNode;
    nrelements++;
    return NULL_TELEM;
}






