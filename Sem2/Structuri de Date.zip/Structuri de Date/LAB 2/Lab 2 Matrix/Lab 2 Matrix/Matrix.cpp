#include "Matrix.h"

Matrix::Matrix(int nrLines, int nrCols) {
    Rows = nrLines;
    Columns = nrCols;
    first = new Node;
    last = new Node;
    first->next = last->previous;
    last->previous = first->next;
}

int Matrix::nrLines() const {
    return Rows;
}

int Matrix::nrColumns() const {
    return Columns;
}

TElem Matrix::element(int i, int j) const {
    if (i < 0 || i >= Rows || j < 0 || j >= Columns) {
        throw std::out_of_range("Invalid position");
    }

    Node* currentNode = first->next;
    while (currentNode != last) {
        if (currentNode->row == i && currentNode->col == j) {
            return currentNode->v;
        }
        currentNode = currentNode->next;
    }

    return NULL_TELEM;
}

TElem Matrix::modify(int i, int j, TElem e) {
    if (i < 0 || i >= Rows || j < 0 || j >= Columns) {
        throw std::out_of_range("Invalid position");
    }

    Node* currentNode = first;
    while (currentNode != last) {
        if (currentNode->row == i && currentNode->col == j) {
            TElem oldValue = currentNode->v;
            currentNode->v = e;
            return oldValue;
        }
        currentNode = currentNode->next;
    }

    Node* newNode = new Node;
    newNode->row = i;
    newNode->col = j;
    newNode->v = e;
    newNode->next = last;
    newNode->previous = last->previous;
    last->previous->next = newNode;
    last->previous = newNode;

    return NULL_TELEM;
}
