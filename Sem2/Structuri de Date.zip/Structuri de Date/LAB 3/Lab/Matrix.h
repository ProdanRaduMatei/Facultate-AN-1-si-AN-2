#pragma once

//DO NOT CHANGE THIS PART
typedef int TElem;
#define NULL_TELEM 0

class Matrix {

private:
	//TODO - Representation
	//represent the matrix as a DLLA
	struct DLLANode {
		TElem value;
		int prev;
		int next;
		int line;
		int column;
		//represent the value of the node
		DLLANode() {
			value = NULL_TELEM;
			prev = -1;
			next = -1;
			line = -1;
			column = -1;
		}
		//constructor
		DLLANode(TElem value, int prev, int next) {
			this->value = value;
			this->prev = prev;
			this->next = next;
		}
	};
	//represent the DLLA
	struct DLLA {
		DLLANode* list;
		int head, tail, firstEmpty;
		int size, capacity;
		int nrLines, nrColumns;
		//constructor
		DLLA() {
			list = new DLLANode[10];
			capacity = 10;
			head = -1;
			tail = -1;
			firstEmpty = 0;
			size = 0;
			nrLines = 0;
			nrColumns = 0;
		}
		//destructor
		DLLANode& operator[](int pos) {
			return list[pos];
		}
	};
	//represent the matrix
	DLLA nodes;
	

public:

	//constructor
	Matrix(int nrLines, int nrCols);

	//destructor
	~Matrix();

	//returns the position of the first empty node
	int allocate();

	//resizes the array of nodes
	void resize();

	//frees the position pos from the array
	void free(int pos);

	//adds an element to the matrix
	void add(int line, int column, TElem value);

	//removes an element from the matrix
	void remove(int Line, int Column);

	//returns the number of lines
	int nrLines() const;

	//returns the number of columns
	int nrColumns() const;

	//returns the element from line i and column j (indexing starts from 0)
	//throws exception if (i,j) is not a valid position in the Matrix
	TElem element(int i, int j) const;

	//modifies the value from line i and column j
	//returns the previous value from the position
	//throws exception if (i,j) is not a valid position in the Matrix
	TElem modify(int i, int j, TElem e);

};
