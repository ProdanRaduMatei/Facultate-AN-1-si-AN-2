#include "Matrix.h"
#include <exception>
using namespace std;

Matrix::Matrix(int nrLines, int nrCols) {
    //TODO - Implementation
    //WC: Theta(1)
    //BC: Theta(1)
    //AC: Theta(1)
    nodes.nrLines = nrLines;
    nodes.nrColumns = nrCols;
    nodes.list = new DLLANode[10];
    nodes.capacity = 10;
    nodes.head = -1;
    nodes.tail = -1;
    nodes.firstEmpty = 0;
    nodes.size = 0;
    for (int i = 0; i < 10; i++) {
        nodes.list[i].next = i + 1;
        nodes.list[i].prev = i - 1;
    }
    nodes.list[9].next = -1;
    nodes.list[0].prev = -1;
}

void Matrix::free(int pos) {
    //frees the position pos from the array
    //WC: Theta(1)
    //BC: Theta(1)
    //AC: Theta(1)
    nodes.list[pos].prev = -1;
    nodes.list[pos].next = nodes.firstEmpty;
    nodes.firstEmpty = pos;
    nodes.size--;
    if (nodes.size == 0) {
        nodes.head = -1;
        nodes.tail = -1;
    }
    else if (pos == nodes.head) {
        nodes.head = nodes.list[pos].next;
        nodes.list[nodes.head].prev = -1;
    }
    else if (pos == nodes.tail) {
        nodes.tail = nodes.list[pos].prev;
        nodes.list[nodes.tail].next = -1;
    }
    else {
        nodes.list[nodes.list[pos].prev].next = nodes.list[pos].next;
        nodes.list[nodes.list[pos].next].prev = nodes.list[pos].prev;
    }
}

int Matrix::allocate() {
    //returns the position of a free element from the array
    //WC: Theta(1)
    //BC: Theta(1)
    //AC: Theta(1)
    int pos = nodes.firstEmpty;
    nodes.firstEmpty = nodes.list[pos].next;
    nodes.size++;
    return pos;
}

void Matrix::resize() {
    //resizes the array of nodes
    //WC: Theta(n)
    //BC: Theta(n)
    //AC: Theta(n)
    DLLANode* newList = new DLLANode[nodes.capacity * 2];
    for (int i = 0; i < nodes.capacity; i++)
        newList[i] = nodes.list[i];
    for (int i = nodes.capacity; i < nodes.capacity * 2; i++) {
        newList[i].next = i + 1;
        newList[i].prev = i - 1;
    }
    newList[nodes.capacity * 2 - 1].next = -1;
    newList[nodes.capacity].prev = -1;
    nodes.firstEmpty = nodes.capacity;
    nodes.capacity *= 2;
    delete[] nodes.list;
    nodes.list = newList;
}

Matrix::~Matrix() {
    //TODO - Implementation
    //WC: Theta(1)
    //BC: Theta(1)
    //AC: Theta(1)
    delete[] nodes.list;
}

void Matrix::add(int Line, int Column, TElem value) {
    //WC: Theta(n)
    //BC: Theta(1)
    //AC: Theta(n)
    if (Line < 0 || Line >= nodes.nrLines || Column < 0 || Column >= nodes.nrColumns)
        throw exception();
    int current = nodes.head;
    while (current != -1) {
        if (nodes.list[current].line == Line && nodes.list[current].column == Column) {
            nodes.list[current].value = value;
            return;
        }
        current = nodes.list[current].next;
    }
    if (nodes.size == nodes.capacity)
        resize();
    int pos = allocate();
    nodes.list[pos].line = Line;
    nodes.list[pos].column = Column;
    nodes.list[pos].value = value;
    if (nodes.head == -1) {
        nodes.head = pos;
        nodes.tail = pos;
    }
    else {
        nodes.list[pos].prev = nodes.tail;
        nodes.list[nodes.tail].next = pos;
        nodes.tail = pos;
    }
}

void Matrix::remove(int Line, int Column) {
    //WC: Theta(n)
    //BC: Theta(1)
    //AC: Theta(n)
    if (Line < 0 || Line >= nodes.nrLines || Column < 0 || Column >= nodes.nrColumns)
        throw exception();
    int current = nodes.head;
    while (current != -1) {
        if (nodes.list[current].line == Line && nodes.list[current].column == Column) {
            free(current);
            return;
        }
        current = nodes.list[current].next;
    }
}

int Matrix::nrLines() const {
    //TODO - Implementation
    //WC: Theta(1)
    //BC: Theta(1)
    //AC: Theta(1)
    return nodes.nrLines;
}


int Matrix::nrColumns() const {
    //TODO - Implementation
    //WC: Theta(1)
    //BC: Theta(1)
    //AC: Theta(1)
    return nodes.nrColumns;
}


TElem Matrix::element(int i, int j) const {
    //TODO - Implementation
    //WC: Theta(n)
    //BC: Theta(1)
    //AC: Theta(n)
    if (i < 0 || i >= nodes.nrLines || j < 0 || j >= nodes.nrColumns)
        throw exception();
    int current = nodes.head;
    while (current != -1) {
        if (nodes.list[current].line == i && nodes.list[current].column == j)
            return nodes.list[current].value;
        current = nodes.list[current].next;
    }
    return NULL_TELEM;
}

TElem Matrix::modify(int i, int j, TElem e) {
    //TODO - Implementation
    //WC: Theta(n)
    //BC: Theta(1)
    //AC: Theta(n)
    if (i < 0 || i >= nodes.nrLines || j < 0 || j >= nodes.nrColumns)
        throw exception();
    int current = nodes.head;
    while (current != -1 && (nodes.list[current].line <= i || nodes.list[current].column <= j)) {
        if (nodes.list[current].line == i && nodes.list[current].column == j) {
            TElem old = nodes.list[current].value;
            //if (e != 0)
                nodes.list[current].value = e;
            return old;
        }
        current = nodes.list[current].next;
    }
    /*if (nodes.size == nodes.capacity)
        resize();
    int pos = allocate();
    nodes.list[pos].line = i;
    nodes.list[pos].column = j;
    nodes.list[pos].value = e;
    if (nodes.head == -1) {
        nodes.head = pos;
        nodes.tail = pos;
    }
    else {
        nodes.list[pos].prev = nodes.tail;
        nodes.list[nodes.tail].next = pos;
        nodes.tail = pos;
    }*/
    return NULL_TELEM;
}


