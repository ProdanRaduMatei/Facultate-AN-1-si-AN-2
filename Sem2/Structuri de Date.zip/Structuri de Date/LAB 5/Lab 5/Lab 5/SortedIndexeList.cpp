#include "ListIterator.h"
#include "SortedIndexedList.h"
#include <iostream>
using namespace std;
#include <exception>

SortedIndexedList::SortedIndexedList(Relation r) {
	//TODO - Implementation
	root = nullptr;
	listSize = 0;
	relation = r;
}

int SortedIndexedList::size() const {
	//TODO - Implementation
	return listSize;
}

bool SortedIndexedList::isEmpty() const {
	//TODO - Implementation
	if (listSize == 0)
		return true;
	return false;
}

TComp SortedIndexedList::getElement(int i) const{
	//TODO - Implementation
	if (i < 0 || i >= listSize)
		throw exception();
	BSTNode* current = root;
	while (current != nullptr) {
		if (current->leftnodes == i)
			return current->info;
		else if (current->leftnodes > i)
			current = current->left;
		else {
			i = i - current->leftnodes - 1;
			current = current->right;
		}
	}
	return NULL_TCOMP;
}

TComp SortedIndexedList::remove(int i) {
	//TODO - Implementation
	if (i < 0 || i >= listSize)
		throw exception();
	BSTNode* current = root;
	BSTNode* parent = nullptr;
	// find the node to be deleted
	while (current != nullptr) {
		if (current->leftnodes == i) { // found the node
			// delete the node
			if (current->left == nullptr && current->right == nullptr) { // no children
				if (parent == nullptr) { // the node is the root
					root = nullptr;
					listSize--;
					return current->info;
				}
				else if (parent->left == current) { // the node is the left child of its parent
					parent->left = nullptr;
					listSize--;
					return current->info;
				}
				else { // the node is the right child of its parent
					parent->right = nullptr;
					listSize--;
					return current->info;
				}
			}
			else if (current->left == nullptr) { // only right child
				if (parent == nullptr) { // the node is the root
					root = current->right;
					listSize--;
					return current->info;
				}
				else if (parent->left == current) { // the node is the left child of its parent
					parent->left = current->right;
					listSize--;
					return current->info;
				}
				else { // the node is the right child of its parent
					parent->right = current->right;
					listSize--;
					return current->info;
				}
			}
			else if (current->right == nullptr) { // only left child
				if (parent == nullptr) { // the node is the root
					root = current->left;
					listSize--;
					return current->info;
				}
				else if (parent->left == current) { // the node is the left child of its parent
					parent->left = current->left;
					listSize--;
					return current->info;
				}
				else { // the node is the right child of its parent
					parent->right = current->left;
					listSize--;
					return current->info;
				}
			}
            else { // both children
                BSTNode* successor = current->right;
                BSTNode* successorParent = current;
                while (successor->left != nullptr) {
                    successorParent = successor;
                    successor = successor->left;
                }
                if (successorParent == current) { // the successor is the right child of the node to be deleted
                    successor->left = current->left;
                    if (parent == nullptr) 
                        root = successor;
                    else if (parent->left == current)
                        parent->left = successor;
                    else
                        parent->right = successor;
                    listSize--;
                    return current->info;
                }
            }
		}
		else if (current->leftnodes > i) { // the node is in the left subtree
			current->leftnodes--;
			parent = current;
			current = current->left;
		}
		else { // the node is in the right subtree
			i = i - current->leftnodes - 1;
			parent = current;
			current = current->right;
		}
	}
	return NULL_TCOMP;
}

int SortedIndexedList::search(TComp e) const {
	//TODO - Implementation
	BSTNode* current = root;
	int position = 0;
	while (current != nullptr) {
		if (relation(current->info, e) == true) {
			position = position + current->leftnodes + 1;
			current = current->right;
		}
		else if (relation(current->info, e) == false) {
			current = current->left;
		}
		else {
			position = position + current->leftnodes;
			return position;
		}
	}
	return -1;
}

void SortedIndexedList::add(TComp e) {
	//TODO - Implementation
	BSTNode* current = root;
	BSTNode* parent = nullptr;
	BSTNode* newNode = new BSTNode;
	newNode->info = e;
	newNode->left = nullptr;
	newNode->right = nullptr;
	newNode->leftnodes = 0;
	if (root == nullptr) {
		root = newNode;
		listSize++;
		return;
	}
}

ListIterator SortedIndexedList::iterator(){
	return ListIterator(*this);
}

//destructor
SortedIndexedList::~SortedIndexedList() {
	//TODO - Implementation
	delete root;
}
