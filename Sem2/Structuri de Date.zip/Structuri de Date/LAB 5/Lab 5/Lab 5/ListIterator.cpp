#include "ListIterator.h"
#include "SortedIndexedList.h"
#include <iostream>

using namespace std;

ListIterator::ListIterator(const SortedIndexedList& list) : list(list) {
	//TODO - Implementation
	current = list.root;
}

void ListIterator::first(){
	//TODO - Implementation
	current = list.root;
}

void ListIterator::next(){
	//TODO - Implementation
	if (current == nullptr)
		throw exception();
	if (current->right != nullptr)
		current = current->right;
	else {
		SortedIndexedList::BSTNode* parent = nullptr;
		while (current != nullptr && current->right == nullptr) {
			parent = current;
			current = current->left;
		}
		if (current == nullptr)
			throw exception();
		current = parent->right;
	}
}

bool ListIterator::valid() const{
	//TODO - Implementation
	return current != nullptr;
}

TComp ListIterator::getCurrent() const{
	//TODO - Implementation
	if (current == nullptr)
		throw exception();
	return current->info;
}


