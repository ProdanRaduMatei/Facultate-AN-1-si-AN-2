#include "SetIterator.h"
#include "Set.h"
#include <exception>


SetIterator::SetIterator(const Set& m) : set(m)
{
	//TODO - Implementation
	current = 0; //current is the index of the current element
}


void SetIterator::first() {
	//TODO - Implementation
	current = 0; //the first element in the array
}


void SetIterator::next() {
	//TODO - Implementation
	if (current == set.nrOfElements) //if the iterator is at the end of the array
		throw std::exception();
	current++; //go to the next element
}


TElem SetIterator::getCurrent()
{
	//TODO - Implementation
	if (current >= set.nrOfElements) //if the iterator is at the end of the array
		throw std::exception();
	else
		return set.elements[current]; //return the current element
}

bool SetIterator::valid() const {
	//TODO - Implementation
	return current < set.nrOfElements; //if the iterator is at the end of the array
}



