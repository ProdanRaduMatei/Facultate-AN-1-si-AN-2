#include "Set.h"
#include "SetITerator.h"

Set::Set() {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	//TODO - Implementation
	capacity = 1;
	nrOfElements = 0;
	elements = new TElem[capacity];
}


bool Set::add(TElem elem) {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(n)
	//TODO - Implementation
	if (search(elem)) { // if the element is already in the set
		return false;
	}
	if (nrOfElements == capacity) { // if the array is full
		capacity *= 2; // double the capacity
		TElem* newElements = new TElem[capacity]; // create a new array with the new capacity
		for (int i = 0; i < nrOfElements; i++) // copy the elements from the old array to the new one
			newElements[i] = elements[i];
		delete[] elements; // delete the old array
		elements = newElements; // make the old array point to the new one
	}
	elements[nrOfElements] = elem; // add the element to the array
	nrOfElements++; // increment the number of elements
	return true;
}


bool Set::remove(TElem elem) {
	//WC - Theta(1)
	//BC - Theta(n)
	//AC - Theta(n)
	//TODO - Implementation
	if (!search(elem)) { // if the element is not in the set
		return false;
	}
	int index = 0;
	while (elements[index] != elem) // find the index of the element
		index++;
	for (int i = index; i < nrOfElements - 1; i++) // shift the elements to the left
		elements[i] = elements[i + 1];
	nrOfElements--; // decrement the number of elements
	return true;
}

bool Set::search(TElem elem) const {
	//WC - Theta(1)
	//BC - Theta(n)
	//AC - Theta(n)
	//TODO - Implementation
	for (int i = 0; i < nrOfElements; i++) // search for the element
		if (elements[i] == elem)
			return true;
	return false;
}


int Set::size() const {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	//TODO - Implementation
	return nrOfElements;
}


bool Set::isEmpty() const {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	//TODO - Implementation
	if (nrOfElements == 0)
		return true;
    return false;
}


Set::~Set() {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	//TODO - Implementation
	delete[] elements;
}


SetIterator Set::iterator() const {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	return SetIterator(*this);
}


