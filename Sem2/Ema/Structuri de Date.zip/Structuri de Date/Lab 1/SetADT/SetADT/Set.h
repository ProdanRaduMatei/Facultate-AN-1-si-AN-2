#pragma once
//DO NOT INCLUDE SETITERATOR

//DO NOT CHANGE THIS PART
typedef int TElem;
#define NULL_TELEM -11111
typedef bool(*Relation)(TElem, TElem); //order relation
class SetIterator;

class Set {
    friend class SetIterator;
private:
    Relation comp; // order relation component
    int arr_size, capacity; // size and capacity
    TElem *array; // the array

public:
    //constructor
    Set(Relation r);

    //adds an element to the sorted set
    //if the element was added, the operation returns true, otherwise (if the element was already in the set)
    //it returns false
    bool add(TElem e);


    //removes an element from the sorted set
    //if the element was removed, it returns true, otherwise false
    bool remove(TElem e);

    //checks if an element is in the sorted set
    bool search(TElem elem) const;


    //returns the number of elements from the sorted set
    int size() const;

    //checks if the sorted set is empty
    bool isEmpty() const;

    //returns an iterator for the sorted set
    SetIterator iterator() const;

    // destructor
    ~Set();
};
