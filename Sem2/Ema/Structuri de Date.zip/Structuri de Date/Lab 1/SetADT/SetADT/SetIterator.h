#pragma once
#include "Set.h"

//DO NOT CHANGE THIS PART
class SetIterator
{
    friend class Set;
private:
    const Set& multime;
    int pos;
    SetIterator(const Set& m);

    //TODO - Representation

public:
    void first();
    void next();
    TElem getCurrent();
    bool valid() const;
};

