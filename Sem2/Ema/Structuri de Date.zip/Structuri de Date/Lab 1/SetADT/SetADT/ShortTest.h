#pragma once

void testAll();
