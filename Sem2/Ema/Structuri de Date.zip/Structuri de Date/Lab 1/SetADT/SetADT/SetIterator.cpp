#include "SetIterator.h"
#include <exception>

using namespace std;

SetIterator::SetIterator(const Set& m) : multime(m)
{
    pos = 0; // constructor
}


void SetIterator::first() {
    pos = 0; // initialize the first position with zero
}


void SetIterator::next() {
    if (pos >= multime.arr_size)
        throw std::exception();
    ++pos;
}


TElem SetIterator::getCurrent()
{
    if (pos >= multime.arr_size)
        throw std::exception();
    return multime.array[pos];
}

bool SetIterator::valid() const {
    return pos < multime.arr_size;
}

