#pragma once

void testAllExtended();
