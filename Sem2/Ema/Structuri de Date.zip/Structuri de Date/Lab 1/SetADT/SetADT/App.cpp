#include "ShortTest.h"
#include "ExtendedTest.h"
#include "Set.h"
#include "SetIterator.h"
#include <iostream>

using namespace std;

int main() {
    testAll();
    testAllExtended();
    cout << "Test end" << endl;
    system("pause");
}
