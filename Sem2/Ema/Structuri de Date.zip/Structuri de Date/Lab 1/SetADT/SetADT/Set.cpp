#include "Set.h"
#include "SetIterator.h"
#include <iostream>

Set::Set(Relation r) {
    //WC: T(1)
    //BC: T(1)
    //AC: T(1)
    comp = r;
    arr_size = 0;
    capacity = 1;
    array = new TElem[1];
}


bool Set::add(TElem elem) {
    //WC: T(n)
    //BC: T(1)
    //AC: O(n)
    if (search(elem)) // checks if the element is already in the array
        return false;
    if (arr_size == capacity){ //checks if there is enough space
        capacity *= 2; //doubles the capacity
        auto* temp = new TElem[capacity]; // creates a new temporay array
        for (int i = 0; i < arr_size; ++i)
            temp[i] = array[i]; // copies the old array in the new array
        delete[] array; // deletes the old array
        array = temp; // saves the new array with the new capacity
    }
    int pos = 0;
    for (int i = 0; i < arr_size; ++i)
        if (comp(array[i], elem))
            pos = i + 1; // searches the position where the elemenet should be placed
        else
            break;
    for (int i = arr_size; i > pos; --i)
        array[i] = array[i - 1]; // creates space in the array at the found position
    array[pos] = elem; // saves the element at the found position in the array
    ++arr_size; // increments the size of the array
    return true;
}


bool Set::remove(TElem elem) {
    //WC: T(n)
    //BC: T(1)
    //AC: O(n)
    if (!search(elem)) // checks if the element is not in the array
        return false;
    bool found = false;
    for (int i = 0; i < arr_size - 1; ++i){
        if (array[i] == elem)
            found = true; // saves that it is found
        if (found)
            array[i] = array[i + 1]; // deletes the element
    }
    --arr_size; // decrements the size of the array
    return true;
}


bool Set::search(TElem elem) const {
    //WC: T(log n)
    //BC: T(1)
    //AC: O(log n)
    int st = 0, dr = arr_size - 1, mid;
    for (mid = (st + dr) / 2; st <= dr; mid = (st + dr) / 2)
        if (array[mid] == elem) // checks if the element is found
            return true;
        else if (comp(array[mid], elem)) // checks if the element is in either of the halfs
            st = mid+1;
        else dr = mid-1;
    return false;
}


int Set::size() const {
    //WC: T(1)
    //BC: T(1)
    //AC: T(1)
    return arr_size;
}



bool Set::isEmpty() const {
    //WC: T(1)
    //BC: T(1)
    //AC: T(1)
    return arr_size == 0;
}

SetIterator Set::iterator() const {
    //WC: T(1)
    //BC: T(1)
    //AC: T(1)
    return SetIterator(*this);
}


Set::~Set() {
    //WC: T(1)
    //BC: T(1)
    //AC: T(1)
    delete[] array;
}


