#pragma once

void testAll();

