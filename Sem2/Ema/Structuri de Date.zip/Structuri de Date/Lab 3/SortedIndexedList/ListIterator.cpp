#include "ListIterator.h"
#include "SortedIndexedList.h"
#include <iostream>

using namespace std;

ListIterator::ListIterator(const SortedIndexedList& list) : list(list) {
	//TODO - Implementation
	current = list.nodes.head;
}

void ListIterator::first(){
	//TODO - Implementation
	current = list.nodes.head;
}

void ListIterator::next(){
	//TODO - Implementation
	if (current == -1)
		throw exception();
	current = list.nodes.elements[current].next;
}

bool ListIterator::valid() const{
	//TODO - Implementation
	if (current == -1)
		return false;
	return true;
}

TComp ListIterator::getCurrent() const{
	//TODO - Implementation
	if (current == -1)
		throw exception();
	return list.nodes.elements[current].info;
}


