#include "ListIterator.h"
#include "SortedIndexedList.h"
#include <iostream>
using namespace std;
#include <exception>

SortedIndexedList::SortedIndexedList(Relation r) {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	//TODO - Implementation
	relation = r;
}

int SortedIndexedList::size() const {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	//TODO - Implementation
	return nodes.size;
}

bool SortedIndexedList::isEmpty() const {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	//TODO - Implementation
	if (nodes.size == 0)
		return true;
	return false;
}

TComp SortedIndexedList::getElement(int i) const{
	//WC - Theta(n)
	//BC - Theta(1)
	//AC - Theta(n)
	//TODO - Implementation
	int current = nodes.head;
	int count = 0;
	while (current != -1 && count < i) {
		current = nodes.elements[current].next;
		count++;
	}
	if (current == -1)
		throw exception();
	return nodes.elements[current].info;
}

TComp SortedIndexedList::remove(int i) {
	//WC - Theta(n)
	//BC - Theta(1)
	//AC - Theta(n)
	//TODO - Implementation
	int current = nodes.head;
	int count = 0;
	if (i < 0 || i >= nodes.size)
		throw exception();
	while (current != -1 && count < i) {
		current = nodes.elements[current].next;
		count++;
	}
	if (current == -1)
		throw exception();
	TComp removed = nodes.elements[current].info;
	if (nodes.elements[current].prev == -1) {
		nodes.head = nodes.elements[current].next;
		if (nodes.head != -1)
			nodes.elements[nodes.head].prev = -1;
	}
	else {
		nodes.elements[nodes.elements[current].prev].next = nodes.elements[current].next;
		if (nodes.elements[current].next != -1)
			nodes.elements[nodes.elements[current].next].prev = nodes.elements[current].prev;
	}
	nodes.elements[current].next = nodes.firstEmpty;
	nodes.firstEmpty = current;
	nodes.size--;
	return removed;
}

int SortedIndexedList::search(TComp e) const {
	//WC - Theta(n)
	//BC - Theta(1)
	//AC - Theta(n)
	//TODO - Implementation
	int current = nodes.head;
	int poz = 0;
	while (current != -1 && nodes.elements[current].info != e) {
		current = nodes.elements[current].next;
		poz++;
	}
	if (current == -1)
		return -1;
	return poz;
}

void SortedIndexedList::add(TComp e) {
	//WC - Theta(n)
	//BC - Theta(1)
	//AC - Theta(n)
	//TODO - Implementation
	if (nodes.firstEmpty == -1) { // resize
		DLLANode* newElements = new DLLANode[nodes.capacity * 2];
		for (int i = 0; i < nodes.capacity; i++) { // copy old elements
			newElements[i].info = nodes.elements[i].info;
			newElements[i].next = nodes.elements[i].next;
			newElements[i].prev = nodes.elements[i].prev;
		}
		for (int i = nodes.capacity; i < nodes.capacity * 2 - 1; i++) { // add new elements
			newElements[i].next = i + 1;
			newElements[i + 1].prev = i;
		}
		newElements[nodes.capacity * 2 - 1].next = -1;
		newElements[nodes.capacity].prev = -1;
		delete[] nodes.elements;
		nodes.elements = newElements;
		nodes.firstEmpty = nodes.capacity;
		nodes.capacity *= 2;
	}
	int current = nodes.head;
	int prev = -1;
	while (current != -1 && relation(nodes.elements[current].info, e)) { // find the position to add the element
		prev = current;
		current = nodes.elements[current].next;
	}
	int newElem = nodes.firstEmpty;
	nodes.firstEmpty = nodes.elements[nodes.firstEmpty].next;
	nodes.elements[newElem].info = e;
	nodes.elements[newElem].next = current;
	nodes.elements[newElem].prev = prev;
	if (prev == -1)
		nodes.head = newElem;
	else
		nodes.elements[prev].next = newElem;
	if (current != -1)
		nodes.elements[current].prev = newElem;
	nodes.size++;
}

ListIterator SortedIndexedList::iterator(){
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	return ListIterator(*this);
}

SortedIndexedList::~SortedIndexedList() {
	//WC - Theta(1)
	//BC - Theta(1)
	//AC - Theta(1)
	//TODO - Implementation
	delete[] nodes.elements;
}
