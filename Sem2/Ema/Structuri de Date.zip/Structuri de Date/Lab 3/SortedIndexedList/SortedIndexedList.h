#pragma once
//DO NOT INCLUDE LISTITERATOR

//DO NOT CHANGE THIS PART
class ListIterator;
typedef int TComp;
typedef bool (*Relation)(TComp, TComp);
#define NULL_TCOMP -11111

class SortedIndexedList {
private:
	friend class ListIterator;
private:
	// TODO - Representation
	struct DLLANode {
		TComp info;
		int next;
		int prev;

		DLLANode() { //constructor
			info = NULL_TCOMP;
			next = -1;
			prev = -1;
		}

		DLLANode(TComp e, int next, int previos) { //constructor
			this->info = e;
			this->next = next;
			this->prev = prev;
		}
	};
	
	struct DLLA {
		DLLANode* elements;
		int head;
		int tail;
		int firstEmpty;
		int capacity;
		int size;

		DLLA() {
			head = -1;
			tail = -1;
			firstEmpty = 0;
			capacity = 10;
			size = 0;
			elements = new DLLANode[capacity];
			for (int i = 0; i < capacity - 1; i++) {
				elements[i].next = i + 1;
				elements[i + 1].prev = i;
			}
			elements[capacity - 1].next = -1;
			elements[0].prev = -1;
		}

		DLLANode& operator[](int pos) {
			return elements[pos];
		}
	};

	//DLLA elements;
	DLLA nodes;
	Relation relation;

public:
	// constructor
	SortedIndexedList(Relation r);

	// returns the size of the list
	int size() const;

	//checks if the list is empty
	bool isEmpty() const;

	// returns an element from a position
	//throws exception if the position is not valid
	TComp getElement(int pos) const;

	// adds an element in the sortedList (to the corresponding position)
	void add(TComp e);

	// removes an element from a given position
	//returns the removed element
	//throws an exception if the position is not valid
	TComp remove(int pos);

	// searches for an element and returns the first position where the element appears or -1 if the element is not in the list
	int search(TComp e) const;

	// returns an iterator set to the first element of the list or invalid if the list is empty
	ListIterator iterator();

	//destructor
	~SortedIndexedList();

};
