#include "SortedBagIterator.h"
#include "SortedBag.h"
#include <exception>

using namespace std;

SortedBagIterator::SortedBagIterator(const SortedBag& b) : bag(b) {
	//TODO - Implementation
	currentKey = 0;
	while (currentKey < bag.capacity && bag.bag[currentKey].elem == -11111)
		currentKey++;
}

TComp SortedBagIterator::getCurrent() {
	//TODO - Implementation
	if (currentKey == bag.capacity)
		throw exception();
	return bag.bag[currentKey].elem;
}

bool SortedBagIterator::valid() {
	//TODO - Implementation
	if (currentKey == bag.capacity)
		return false;
	return true;
}

void SortedBagIterator::next() {
	//TODO - Implementation
	if (currentKey == bag.capacity)
		throw exception();
	if (bag.bag[currentKey].next != nullptr) {
		currentKey = bag.bag[currentKey].next->key;
		return;
	}
	for (int i = currentKey + 1; i < bag.capacity; i++) {
		if (bag.bag[i].elem != -11111) {
			currentKey = i;
			return;
		}
	}
	throw exception();
}

void SortedBagIterator::first() {
	//TODO - Implementation
	for (int i = 0; i < bag.capacity; i++) {
		if (bag.bag[i].elem != -11111) {
			currentKey = i;
			return;
		}
	}
	throw exception();
}

