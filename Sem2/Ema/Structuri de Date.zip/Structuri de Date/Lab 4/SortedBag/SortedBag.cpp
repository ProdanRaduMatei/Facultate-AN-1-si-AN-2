#include "SortedBag.h"
#include "SortedBagIterator.h"

SortedBag::SortedBag(Relation r) {
	//TODO - Implementation
	relation = r;
	capacity = 10;
	bagSize = 0;
	bag = new hashTable[capacity];
}

void SortedBag::add(TComp e) {
	//TODO - Implementation
	if (bagSize == capacity)
		resize();
	int key = e % capacity;
	if (key < 0)
		key += capacity;
	if (bag[key].elem == -11111) {
		bag[key].elem = e;
		bag[key].key = key;
		bag[key].next = nullptr;
	}
	else {
		hashTable* newElem = new hashTable;
		newElem->elem = e;
		newElem->key = key;
		newElem->next = bag[key].next;
		bag[key].next = newElem;
	}
	bagSize++;
}


bool SortedBag::remove(TComp e) {
	//TODO - Implementation
	int key = e % capacity;
	if (key < 0)
		key += capacity;
	if (bag[key].elem == e) {
		bag[key].elem = bag[key].next->elem;
		bag[key].key = bag[key].next->key;
		bag[key].next = bag[key].next->next;
		bagSize--;
		return true;
	}
	else {
		hashTable* current = bag[key].next;
		hashTable* previous = &bag[key];
		while (current != nullptr) {
			if (current->elem == e) {
				previous->next = current->next;
				bagSize--;
				return true;
			}
			previous = current;
			current = current->next;
		}
	}
	return false;
}


bool SortedBag::search(TComp elem) const {
	//TODO - Implementation
	int key = elem % capacity;
	if (key < 0)
		key += capacity;
	if (bag[key].elem == elem)
		return true;
	else {
		hashTable* current = bag[key].next;
		while (current != nullptr) {
			if (current->elem == elem)
				return true;
			current = current->next;
		}
	}
	return false;
}


int SortedBag::nrOccurrences(TComp elem) const {
	//TODO - Implementation
	int key = elem % capacity;
	if (key < 0)
		key += capacity;
	if (bag[key].elem == elem) {
		int count = 1;
		hashTable* current = bag[key].next;
		while (current != nullptr) {
			if (current->elem == elem)
				count++;
			current = current->next;
		}
		return count;
	}
	else {
		hashTable* current = bag[key].next;
		while (current != nullptr) {
			if (current->elem == elem)
				return 1;
			current = current->next;
		}
	}
	return 0;
}



int SortedBag::size() const {
	//TODO - Implementation
	return bagSize;
}


bool SortedBag::isEmpty() const {
	//TODO - Implementation
	return bagSize == 0;
}


SortedBagIterator SortedBag::iterator() const {
	return SortedBagIterator(*this);
}


SortedBag::~SortedBag() {
	//TODO - Implementation
	delete[] bag;
}

int SortedBag::hashFunction(int k, int capacity) const {
	return k % capacity;
}

void SortedBag::resize() {
	//TODO - Implementation
	hashTable* newBag = new hashTable[capacity * 2];
	for (int i = 0; i < capacity; i++)
		newBag[i] = bag[i];
	delete[] bag;
	bag = newBag;
	capacity *= 2;
}