#include "Matrix.h"
#include <exception>
using namespace std;


Matrix::Matrix(int nrLines, int nrCols)  {
	//TODO - Implementation
	nrlines = nrLines;
	nrcols = nrCols;
	root = NULL;
}


int Matrix::nrLines() const {
	//TODO - Implementation
	return nrlines;
}


int Matrix::nrColumns() const {
	//TODO - Implementation
	return nrcols;
}


TElem Matrix::element(int i, int j) const {
	//TODO - Implementation
	if (i < 0 || i >= nrlines || j < 0 || j >= nrcols)
		throw exception();
	BSTNode* current = root;
	while (current != NULL) {
		if (current->line == i && current->col == j)
			return current->value;
		else if (current->line > i)
			current = current->left;
		else if (current->line < i)
			current = current->right;
		else if (current->line == i && current->col > j)
			current = current->left;
		else if (current->line == i && current->col < j)
			current = current->right;
	}
	return NULL_TELEM;
}

TElem Matrix::modify(int i, int j, TElem e) {
	//TODO - Implementation
	if (i < 0 || i >= nrlines || j < 0 || j >= nrcols)
		throw exception();
	BSTNode* current = root;
	BSTNode* previous = NULL;
	while (current != NULL) {
		if (current->line == i && current->col == j) {
			TElem old = current->value;
			current->value = e;
			return old;
		}
		else if (current->line > i) {
			previous = current;
			current = current->left;
		}
		else if (current->line < i) {
			previous = current;
			current = current->right;
		}
		else if (current->line == i && current->col > j) {
			previous = current;
			current = current->left;
		}
		else if (current->line == i && current->col < j) {
			previous = current;
			current = current->right;
		}
	}
	BSTNode* newNode = new BSTNode;
	newNode->value = e;
	newNode->line = i;
	newNode->col = j;
	newNode->left = NULL;
	newNode->right = NULL;

	//Handle the case when the tree is empty
	if (previous == NULL)
        root = newNode;
    else if (previous->line > i)
        previous->left = newNode;
    else if (previous->line < i)
        previous->right = newNode;
    else if (previous->line == i && previous->col > j)
        previous->left = newNode;
    else if (previous->line == i && previous->col < j)
        previous->right = newNode;
	return NULL_TELEM;
}


