#ifndef CONTAINER_H
#define CONTAINER_H
#include <vector>

#include "entertainmentevent.h"

class EntertainmentContainer {
private:
    vector<EntertainmentEvent*> entertainmentEvents;

public:
    void addMovie(const string& id, const string& dayOfTheWeek, const string& name, int duration);

    void addDinner(const string& id, const string& dayOfTheWeek, int maxBudget, const string& location);

    vector<EntertainmentEvent*> getAll() const;

    vector<EntertainmentEvent*> filterByDay(const string& dayOfTheWeek) const;
};
#endif // CONTAINER_H
