#include "mainwindow.h"
#include "ui_mainwindow.h"

#include "container.h"
#include "entertainmentevent.h"
#include <QMessageBox>
#include <QTableWidgetItem>
#include <QFileDialog>
#include <QTextStream>
#include <QFile>


MainWindow::MainWindow(QWidget parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_addMovieButton_clicked()
{
    QString id = ui->idLineEdit->text();
    QString dayOfWeek = ui->dayOfWeekLineEdit->text();
    QString movieName = ui->movieNameLineEdit->text();
    int duration = ui->movieDurationLineEdit->text().toInt();

    container.addMovie(id.toStdString(), dayOfWeek.toStdString(), movieName.toStdString(), duration);

    QMessageBox::information(this, "Success", "Movie added successfully.");
}

void MainWindow::on_addDinnerButton_clicked()
{
    QString id = ui->idLineEdit->text();
    QString dayOfWeek = ui->dayOfWeekLineEdit->text();
    int budget = ui->dinnerBudgetLineEdit->text().toInt();
    QString location = ui->dinnerLocationLineEdit->text();

    container.addDinner(id.toStdString(), dayOfWeek.toStdString(), budget, location.toStdString());

    QMessageBox::information(this, "Success", "Dinner added successfully.");
}

void MainWindow::on_getAllButton_clicked()
{
    ui->outputLabel->clear();

    std::vector<EntertainmentEvent> events = container.getAll();
    for (const auto& event : events) {
        QString eventText = QString::fromStdString(event->toString());
        ui->outputLabel->appendPlainText(eventText);
    }
}

void MainWindow::on_filterButton_clicked()
{
    ui->outputLabel->clear();

    QString dayOfWeek = ui->dayOfWeekLineEdit->text();
    std::vector<EntertainmentEvent*> events = container.filterByDay(dayOfWeek.toStdString());
    for (const auto& event : events) {
        QString eventText = QString::fromStdString(event->toString());
        ui->outputLabel->appendPlainText(eventText);
    }
}