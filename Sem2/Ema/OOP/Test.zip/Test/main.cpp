#include "mainwindow.h"
#include "container.h"
#include <QApplication>
#include <iostream>
#include <string>

using namespace std;

int main2() {
    EntertainmentContainer container;
    container.addMovie("M001", "Monday", "The Avengers", 180);
    container.addDinner("D001", "Friday", 100, "Restaurant XYZ");
    container.addMovie("M002", "Monday", "Inception", 150);

    vector<EntertainmentEvent*> allEvents = container.getAll();
    cout << "All Events:\n";
    for (const auto& event : allEvents) {
        cout << event->toString() << endl;
    }

    cout << "\nFiltered Events (Monday):\n";
    vector<EntertainmentEvent*> filteredEvents = container.filterByDay("Monday");
    for (const auto& event : filteredEvents) {
        cout << event->toString() << endl;
    }

    for (const auto& event : allEvents) {
        delete event;
    }
    return 0;
}

int main(int argc, char *argv[])
{
    QApplication a(argc, argv);
    MainWindow w;
    w.show();
    return a.exec();
}


