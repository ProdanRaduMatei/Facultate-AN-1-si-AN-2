#include "container.h"

void EntertainmentContainer::addMovie(const string& id, const string& dayOfTheWeek, const string& name, int duration) {
        entertainmentEvents.push_back(new MovieNight(id, dayOfTheWeek, name, duration));
}

void EntertainmentContainer::addDinner(const string& id, const string& dayOfTheWeek, int maxBudget, const string& location) {
    entertainmentEvents.push_back(new DinnerInTown(id, dayOfTheWeek, maxBudget, location));
}

vector<EntertainmentEvent*> EntertainmentContainer::getAll() const {
    return entertainmentEvents;
}

vector<EntertainmentEvent*> EntertainmentContainer::filterByDay(const string& dayOfTheWeek) const {
    vector<EntertainmentEvent*> filteredEvents;
    for (const auto& event : entertainmentEvents) {
        if (event->dayOfTheWeek == dayOfTheWeek) {
            filteredEvents.push_back(event);
        }
    }
    return filteredEvents;
}