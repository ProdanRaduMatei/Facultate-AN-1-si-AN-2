#include "entertainmentevent.h"

EntertainmentEvent::EntertainmentEvent(const string& id, const string& dayOfTheWeek)
    : id(id), dayOfTheWeek(dayOfTheWeek) {}

string EntertainmentEvent::toString() const {
    return "Event ID: " + id + ", Day of the Week: " + dayOfTheWeek;
}

MovieNight::MovieNight(const string& id, const string& dayOfTheWeek, const string& name, int duration)
    : EntertainmentEvent(id, dayOfTheWeek), name(name), duration(duration) {}

string MovieNight::toString() const {
    return EntertainmentEvent::toString() + ", Name: " + name + ", Duration: " + to_string(duration) + " minutes";
}

DinnerInTown::DinnerInTown(const string& id, const string& dayOfTheWeek, int maxBudget, const string& location)
    : EntertainmentEvent(id, dayOfTheWeek), maxBudget(maxBudget), location(location) {}

string DinnerInTown::toString() const {
    return EntertainmentEvent::toString() + ", Max Budget: $" + to_string(maxBudget) + ", Location: " + location;
}