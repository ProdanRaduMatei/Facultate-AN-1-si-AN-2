#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QMessageBox>
#include <QFileDialog>
#include <QTextStream>
#include <QFile>
#include <QTextStream>

#include "container.h"
#include "entertainmentevent.h"


QT_BEGIN_NAMESPACE
namespace Ui { class MainWindow; }
QT_END_NAMESPACE

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    MainWindow(QWidget parent = nullptr);
    ~MainWindow();

private slots:
    void on_addMovieButton_clicked();
    void on_addDinnerButton_clicked();
    void on_getAllButton_clicked();
    void on_filterButton_clicked();

private:
    Ui::MainWindowui;
    EntertainmentContainer container;
};

#endif // MAINWINDOW_H
