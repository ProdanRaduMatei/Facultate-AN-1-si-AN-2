#include <string>
#include <vector>
#include <iostream>

using namespace std;

class EntertainmentEvent {
public:
    string id;
    string dayOfTheWeek;
    EntertainmentEvent(const string& id, const string& dayOfTheWeek);
    virtual string toString() const;
};

class MovieNight : public EntertainmentEvent {
private:
    string name;
    int duration;

public:
    MovieNight(const string& id, const string& dayOfTheWeek, const string& name, int duration);

    string toString() const override;
};

class DinnerInTown : public EntertainmentEvent {
private:
    int maxBudget;
    string location;

public:
    DinnerInTown(const string& id, const string& dayOfTheWeek, int maxBudget, const string& location);

    string toString() const override;
};
