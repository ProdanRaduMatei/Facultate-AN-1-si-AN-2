package repository;

import domain.Car;

public class CarRepo extends MemoryRepository<Integer, Car> {
}
