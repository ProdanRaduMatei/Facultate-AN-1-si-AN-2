package repository;

import domain.Doctor;

public class DoctorRepository extends MemoryRepository<Integer, Doctor> {
}
