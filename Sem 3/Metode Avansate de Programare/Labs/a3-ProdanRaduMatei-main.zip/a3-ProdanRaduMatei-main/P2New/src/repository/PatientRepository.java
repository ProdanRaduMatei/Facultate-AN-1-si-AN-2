package repository;

import domain.Patient;

public class PatientRepository extends MemoryRepository<Integer, Patient> {
}
