package repository;
import domain.Book;

public class BookMemoryRepository extends MemoryRepository<Book, Integer> {
}
