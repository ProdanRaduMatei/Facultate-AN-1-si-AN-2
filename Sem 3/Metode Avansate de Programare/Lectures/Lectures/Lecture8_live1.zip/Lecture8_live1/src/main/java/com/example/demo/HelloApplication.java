package com.example.demo;

import domain.Student;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.EventHandler;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Arrays;

public class HelloApplication extends Application {
    ListView<Student> studentsListView = new ListView<>();
    Button addButton = new Button("Add");
    Button removeButton = new Button("Remove");
    TextField idTextField = new TextField();
    TextField nameTextField = new TextField();
    TextField averageTextField = new TextField();

    ObservableList<Student> list;

    public Scene createScene()
    {
        HBox hbox = new HBox();
        Scene scene = new Scene(hbox, 500, 300);
        hbox.getChildren().add(studentsListView);

        GridPane studentsDataPane = new GridPane();
        studentsDataPane.add(new Label("Id"), 0, 0);
        studentsDataPane.add(idTextField, 1, 0);
        studentsDataPane.add(new Label("Name"), 0, 1);
        studentsDataPane.add(nameTextField, 1, 1);
        studentsDataPane.add(new Label("Average"), 0, 2);
        studentsDataPane.add(averageTextField, 1, 2);
        studentsDataPane.add(addButton, 0, 3);
        studentsDataPane.add(removeButton, 1, 3);

        hbox.getChildren().add(studentsDataPane);

        return scene;
    }

    public void handleEvents()
    {
//        EventHandler<MouseEvent> addHandler = new EventHandler<MouseEvent>() {
//            @Override
//            public void handle(MouseEvent mouseEvent) {
//                String id = idTextField.getText();
//                String name = nameTextField.getText();
//                String average = averageTextField.getText();
//                Student student = new Student(Integer.parseInt(id), name, Double.parseDouble(average));
//                list.add(student);
//            }
//        };

//        EventHandler<MouseEvent> addHandler = (event -> {
//                String id = idTextField.getText();
//                String name = nameTextField.getText();
//                String average = averageTextField.getText();
//                Student student = new Student(Integer.parseInt(id), name, Double.parseDouble(average));
//                list.add(student);
//        });
//
//        EventHandler<MouseEvent> addFilter = new EventHandler<MouseEvent>() {
//            @Override
//            public void handle(MouseEvent mouseEvent) {
//                //System.out.println("Filter for the add button.");
//                //mouseEvent.consume();
//            }
//        };
//
//        addButton.addEventHandler(MouseEvent.MOUSE_CLICKED, addHandler);
//        addButton.addEventFilter(MouseEvent.MOUSE_CLICKED, addFilter);

        addButton.setOnMouseClicked(event -> {
                String id = idTextField.getText();
                String name = nameTextField.getText();
                String average = averageTextField.getText();
                Student student = new Student(Integer.parseInt(id), name, Double.parseDouble(average));
                list.add(student);
            });

        studentsListView.setOnMouseClicked(event ->
        {
            int idx = studentsListView.getSelectionModel().getSelectedIndex();
            if (idx < 0)
                return;
            Student s = list.get(idx);
            idTextField.setText(String.valueOf(s.getId()));
            nameTextField.setText(s.getName());
            averageTextField.setText(String.valueOf(s.getAverage()));
        });

        removeButton.setOnMouseClicked(event ->
        {
            int idx = studentsListView.getSelectionModel().getSelectedIndex();
            list.remove(idx);
        });
    }

    private void populateList()
    {
        Student s1 = new Student(1, "Mihai", 8.70);
        Student s2 = new Student(2, "Ana", 9.70);
        Student s3 = new Student(3, "Ionut", 4);

        list = FXCollections.observableArrayList(Arrays.asList(s1, s2, s3));
        studentsListView.setItems(list);
    }

    @Override
    public void start(Stage stage) throws IOException {
        Scene scene = createScene();
        populateList();
        stage.setTitle("Fist JavaFX app!");
        stage.setScene(scene);
        handleEvents();
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}