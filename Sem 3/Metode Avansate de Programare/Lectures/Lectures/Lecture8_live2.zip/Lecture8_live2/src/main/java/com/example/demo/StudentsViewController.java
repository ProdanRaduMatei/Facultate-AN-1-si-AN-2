package com.example.demo;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;

import java.util.Arrays;

public class StudentsViewController {
    @FXML
    private Button addButton;

    @FXML
    private TextField averageTextField;

    @FXML
    private TextField idTextField;

    @FXML
    private TextField nameTextField;

    @FXML
    private Button removeButton;

    @FXML
    private ListView<Student> studentsListView;

    ObservableList<Student> list;

    private void populateList()
    {
        Student s1 = new Student(1, "Mihai", 8.70);
        Student s2 = new Student(2, "Ana", 9.70);
        Student s3 = new Student(3, "Ionut", 4);

        list = FXCollections.observableArrayList(Arrays.asList(s1, s2, s3));
        studentsListView.setItems(list);
    }

    public void initialize()
    {
        populateList();

        studentsListView.setOnMouseClicked(event ->
        {
            int idx = studentsListView.getSelectionModel().getSelectedIndex();
            if (idx < 0)
                return;
            Student s = list.get(idx);
            idTextField.setText(String.valueOf(s.getId()));
            nameTextField.setText(s.getName());
            averageTextField.setText(String.valueOf(s.getAverage()));
        });
    }

    @FXML
    void addButtonAction(MouseEvent event) {
        String id = idTextField.getText();
        String name = nameTextField.getText();
        String average = averageTextField.getText();
        Student student = new Student(Integer.parseInt(id), name, Double.parseDouble(average));
        list.add(student);
    }
}
