package com.example.demo;

import domain.Student;
import javafx.application.Application;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Arrays;

public class HelloApplication extends Application {
    ListView<Student> studentsListView = new ListView<>();
    Button addButton = new Button("Add");
    Button removeButton = new Button("Remove");

    public Scene createScene()
    {
        VBox vbox = new VBox();
        Scene scene = new Scene(vbox, 300, 300);
        vbox.getChildren().add(studentsListView);
        HBox buttonsBox = new HBox();
        buttonsBox.getChildren().add(addButton);
        buttonsBox.getChildren().add(removeButton);
        vbox.getChildren().add(buttonsBox);

        return scene;
    }

    private void populateList()
    {
        Student s1 = new Student(1, "Mihai", 8.70);
        Student s2 = new Student(2, "Ana", 9.70);
        Student s3 = new Student(3, "Ionut", 4);

        ObservableList<Student> list = FXCollections.observableArrayList(Arrays.asList(s1, s2, s3));
        studentsListView.setItems(list);
    }

    @Override
    public void start(Stage stage) throws IOException {
        Scene scene = createScene();
        populateList();
        stage.setTitle("Fist JavaFX app!");
        stage.setScene(scene);
        stage.show();
    }

    public static void main(String[] args) {
        launch();
    }
}