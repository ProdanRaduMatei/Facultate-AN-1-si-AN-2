package java8features;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

public class MethodsOnMap {
    public static void main(String[] args) {
        Map<Integer, Student> students = new HashMap<>();
        Student s1 = new Student(1, "Mihai", 8.70);
        Student s2 = new Student(2, "Ana", 8.70);
        Student s3 = new Student(3, "Ionut", 9);
        students.put(s1.getId(), s1);
        students.put(s2.getId(), s2);
        students.putIfAbsent(s3.getId(), s3); // new student is added
        students.putIfAbsent(s3.getId(), s3); // if it already exists, the student is not added
        for (Integer id: students.keySet())
            System.out.println(students.get(id));
    }
}
