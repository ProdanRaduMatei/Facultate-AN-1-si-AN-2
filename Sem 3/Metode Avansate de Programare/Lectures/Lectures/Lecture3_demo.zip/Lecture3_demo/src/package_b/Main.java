package package_b;

//import package_a.A;
//import package_a.B;

public class Main {
    public static void main(String[] args) {
        package_a.A a = new package_a.A();
//        A a1 = new A();
//        B b = new B();
    }
}
