package package_a;

public class B {
}
