package package_a;

public class A {
}
