class MyException extends Exception {
    public MyException(String message) {
        super(message);
    }
}

class MySecondException extends Exception {
    public MySecondException(String message) {
        super(message);
    }
}

class Employee {
    protected double salary;

    public Employee(double salary) throws MyException {
        if (salary < 0)
            throw new MyException("Salary cannot be less than 0!");
        this.salary = salary;
    }

    public double totalSalary() throws MyException {
        return salary;
    }
}

class Manager extends Employee {
    private double bonus;

    public Manager(double salary, double bonus) throws MyException {
        super(salary);
        this.bonus = bonus;
    }

    @Override
    public double totalSalary() {
        return salary + bonus;
    }
}

public class Exceptions {
    // ax + b = 0;
    public static double solveEquation(double[] coefficients) throws MyException {
        if (coefficients.length != 2)
            throw new IllegalArgumentException("Please input at least two parameters!");
        if (coefficients[0] == 0)
            throw new MyException("First coefficient cannot be zero!");
        double res = -coefficients[1]/coefficients[0];
        return res;
    }

    public static void main(String[] args) {
        try
        {
            double [] coefficients = new double[2];
            coefficients[0] = 1;
            coefficients[1] = 2;
            System.out.println(solveEquation(coefficients));
            System.out.println("Hello!");
        }
        catch (IllegalArgumentException ex)
        {
            System.out.println(ex.getMessage());
        }
        catch (ArithmeticException ex)
        {
            System.out.println(ex.getMessage());
        } catch (MyException e) {
            throw new RuntimeException(e);
        } finally {
            System.out.println("Done! One way or another...");
        }
    }
}
