import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;

class Person {
    protected String name;

    public Person(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    @Override
    public String toString() {
        return "Person{" +
                "name='" + name + '\'' +
                '}';
    }
}

class Student extends Person implements Comparable<Student> {
    private double grade;

    public Student(String name, double grade) {
        super(name);
        this.grade = grade;
    }

    @Override
    public String toString() {
        return "Student{" +
                "name="+ name + ", " +
                "grade=" + grade +
                '}';
    }

    public double getGrade() {
        return grade;
    }

    @Override
    public int compareTo(Student o) {
        return this.name.compareTo(o.name);
    }
}

class MyVector<T> implements Iterable<T>
{
    private T[] elems;

    public MyVector(T[] elems) {
        this.elems = elems;
    }

    @Override
    public Iterator<T> iterator() {
        return new MyIterator();
    }

    class MyIterator implements Iterator<T>
    {
        int current = 0;

        @Override
        public boolean hasNext() {
            return current < elems.length;
        }

        @Override
        public T next() {
            T currentElem = (T)elems[current];
            current++;
            return  currentElem;
        }
    }
}

class StudentNameComparator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        return o1.name.compareTo(o2.name);
    }
}

class StudentGradeComparator implements Comparator<Student> {

    @Override
    public int compare(Student o1, Student o2) {
        if (o1.getGrade() < o2.getGrade())
            return 1;
        else if (o1.getGrade() > o2.getGrade())
            return -1;
        return 0;
    }
}

public class Main {

    public static void printPersons(ArrayList<? extends Person> persons)
    {
        for (Person p: persons)
            System.out.println(p);
    }

    public static void main(String[] args) {
        Student stud1 = new Student("John", 9);
        Student stud2 = new Student("Mark", 8);
        Student stud3 = new Student("Anna", 10);

        Person p = stud1;

        Student[] students = new Student[3];
        students[0] = stud1;
        students[1] = stud2;
        Person[] persons = new Person[3];
        persons = students;
//        persons[2] = new Person("Mother");
//
//        Student s = (Student)persons[2];

        ArrayList<Student> studentsA = new ArrayList<>();
        studentsA.add(stud1);
        studentsA.add(stud2);
        studentsA.add(stud3);
//        ArrayList<Person> personsA = new ArrayList<>();
//
//        printPersons(studentsA);

//        Collections.sort(studentsA, new StudentGradeComparator());
//        for (Student s: studentsA)
//            System.out.println(s);

        MyVector<Student> vector = new MyVector<>(students);
        for (Student s: vector)
            System.out.println(s);
    }
}