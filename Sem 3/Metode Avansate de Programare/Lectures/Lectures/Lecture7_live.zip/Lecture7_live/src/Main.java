import entities.Discipline;
import entities.Student;
import entities.StudentDiscipline;

import java.util.ArrayList;
import java.util.*;
import java.util.function.BinaryOperator;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.function.Supplier;
import java.util.stream.Collectors;
import java.util.stream.Stream;

@FunctionalInterface
interface Operation
{
    Integer applyOperation(Integer a, Integer b);
}

public class Main {
    public static Integer applyOperationOnList(ArrayList<Integer> list, Operation o)
    {
        Integer result = list.get(0);
        for (int i = 1; i < list.size(); i++)
            result = o.applyOperation(result, list.get(i));
        return result;
    }

    public static void main(String[] args) {
        Operation oper = (a, b) -> a + b;
        System.out.println(oper.applyOperation(5, 10));

        ArrayList<Integer> elems = new ArrayList<>(Arrays.asList(1, 2, 3, 4));
        System.out.println(applyOperationOnList(elems, oper));

        Student s1 = new Student(1, "Mihai", 8.70);
        Student s2 = new Student(2, "Ana", 9.70);
        Student s3 = new Student(3, "Ionut", 4);
        ArrayList<Student> studentsList = new ArrayList<>(Arrays.asList(s1, s2, s3));

        // Predicate
        Predicate<Student> hasPassed = s -> s.getAverage() > 5;
//        for (Student s: studentsList)
//            if (hasPassed.test(s))
//                System.out.println(s);

//        System.out.println();

        Predicate<Student> firstHalf = s -> s.getName().compareTo("M") < 0;
//        for (Student s: studentsList)
//            if (firstHalf.test(s))
//                System.out.println(s);

//        System.out.println();

        Predicate<Student> firstHalfAndHasPassed = hasPassed.and(firstHalf);
//        for (Student s: studentsList)
//            if (firstHalfAndHasPassed.test(s))
//                System.out.println(s);

        // Supplier
        Supplier<String> supplier = new Supplier<String>() {
            @Override
            public String get() {
                Random r = new Random();
                String[] letters = {"A", "G", "E", "O", "V"};
                int length = letters.length;
                String word = letters[r.nextInt(length)] + letters[r.nextInt(length)] +
                        letters[r.nextInt(length)];
                return word;
            }
        };
//        System.out.println(supplier.get());

        // Consumer
        Consumer<Student> consumer = new Consumer<Student>() {
            @Override
            public void accept(Student student) {
                System.out.println(student.getName());
            }
        };
//        consumer.accept(s1);


        List<String> names = Arrays.asList("Barbara", "James", "Brooke", "Emilia", "Boris");

        // map -> toUpper
        Stream<String> stream = names.stream();
        stream.map(s->s.toUpperCase())
                .forEach(System.out::println);

        // filter -> ends with "a"
        names.stream()
                .filter(s->s.endsWith("a"))
                .forEach(System.out::println);

        // reverse sort
        names.stream()
                .sorted(new Comparator<String>() {
                    @Override
                    public int compare(String o1, String o2) {
                        return o1.compareTo(o2);
                    }
                }.reversed())
                .forEach(System.out::println);

        // reduce -> concat names
        System.out.println(
        names.stream()
                .reduce((x, y) -> x.concat(" - ").concat(y))
                .get());

        // reduce -> sum
        System.out.println(elems.stream()
                .reduce(Integer::min)
                .get());

//        Stream.of("d2", "a2", "b1", "b3", "c")
//                .map(s -> {
//                    System.out.println("map: " + s);
//                    return s.toUpperCase();
//                })
//                .filter(s -> {
//                    System.out.println("filter: " + s);
//                    return s.startsWith("A");
//                })
//                .forEach(s -> System.out.println("forEach: " + s));

        Discipline d1 = new Discipline(1, "APM");
        Discipline d2 = new Discipline(2, "DB");
        StudentDiscipline sd1 = new StudentDiscipline(s1, d1);
        StudentDiscipline sd2 = new StudentDiscipline(s1, d2);
        StudentDiscipline sd3 = new StudentDiscipline(s2, d1);
        StudentDiscipline sd4 = new StudentDiscipline(s3, d1);
        StudentDiscipline sd5 = new StudentDiscipline(s3, d2);

        // reduce -> get student with highest grade
        System.out.println(
        studentsList.stream()
                .reduce(BinaryOperator.maxBy(new Comparator<Student>() {
                    @Override
                    public int compare(Student o1, Student o2) {
                        if (o1.getAverage() < o2.getAverage())
                            return -1;
                        else if (o1.getAverage() > o2.getAverage())
                                return 1;
                        return 0;
                    }
                }))
                .get());

        // all students who study "APM", sorted alphabetically
        List<Student> result =
        Stream.of(sd1, sd2, sd3, sd4, sd5)
                .filter(sd -> sd.getDiscipline().getName().equals("APM"))
                .map(sd -> sd.getStudent())
                .sorted()
                .collect(Collectors.toList());
        result.forEach(System.out::println);

        // student who study "APM", having the greatest average
        System.out.println(
        Stream.of(sd1, sd2, sd3, sd4, sd5)
                .filter(sd -> sd.getDiscipline().getName().equals("APM"))
                .map(sd -> sd.getStudent())
                .reduce(BinaryOperator.maxBy(new Comparator<Student>() {
                    @Override
                    public int compare(Student o1, Student o2) {
                        if (o1.getAverage() < o2.getAverage())
                            return -1;
                        else if (o1.getAverage() > o2.getAverage())
                            return 1;
                        return 0;
                    }
                }))
                .get());
    }
}