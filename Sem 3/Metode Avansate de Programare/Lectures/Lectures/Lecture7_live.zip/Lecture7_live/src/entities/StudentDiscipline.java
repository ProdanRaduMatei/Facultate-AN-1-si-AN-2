package entities;

public class StudentDiscipline
{
    private Student student;
    private Discipline discipline;

    public StudentDiscipline(Student student, Discipline discipline) {
        this.student = student;
        this.discipline = discipline;
    }

    public int getId()
    {
        return Integer.parseInt(Integer.toString(student.getId()) + Integer.toString(discipline.getId()));
    }

    public Student getStudent() {
        return student;
    }

    public Discipline getDiscipline() {
        return discipline;
    }

    @Override
    public String toString() {
        return "StudentDiscipline{" +
                "student=" + student +
                ", discipline=" + discipline +
                '}';
    }
}
