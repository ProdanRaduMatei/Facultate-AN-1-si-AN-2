public interface Checker {
    boolean check(Section s);
}
