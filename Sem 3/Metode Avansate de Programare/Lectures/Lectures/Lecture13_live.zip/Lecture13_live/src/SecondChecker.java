public class SecondChecker implements Checker {
    @Override
    public boolean check(Section s) {
        boolean titleCorrect = (s.getTitle().split("[ ]").length == 1);
        boolean contentCorrect = (s.getContent().split("[ ]]").length <= 300);
        return (titleCorrect && contentCorrect);
    }
}
