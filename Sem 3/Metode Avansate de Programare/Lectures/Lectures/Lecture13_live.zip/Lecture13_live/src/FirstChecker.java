public class FirstChecker implements Checker{
    @Override
    public boolean check(Section s) {
        String firstLetter = s.getTitle().substring(0,1);
        boolean titleCorrect = firstLetter.toUpperCase().equals(firstLetter);
        boolean contentCorrect = (s.getContent().split("[.]").length > 2);
        return (titleCorrect && contentCorrect);
    }
}
