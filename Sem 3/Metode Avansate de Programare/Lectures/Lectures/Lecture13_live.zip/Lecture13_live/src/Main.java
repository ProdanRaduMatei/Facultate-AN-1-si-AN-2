public class Main {
    public static void main(String[] args) {
        Section section1 = new Section("Title 1",
                "Sentence 1. Sentence 2. Sentence 3",
                new FirstChecker());
        section1.generate();

        Section section2 = new Section("Title two words",
                "content",
                new SecondChecker());
        section2.generate();
    }
}