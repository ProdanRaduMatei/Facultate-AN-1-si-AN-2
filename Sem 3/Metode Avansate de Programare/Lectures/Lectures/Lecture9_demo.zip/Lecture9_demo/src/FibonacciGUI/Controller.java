package FibonacciGUI;

import javafx.concurrent.Task;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;

public class Controller {
    @FXML private TextField textField1;
    @FXML private Button buttonCompute1;
    @FXML private Label label1;

    @FXML private TextField textField2;
    @FXML private Button buttonCompute2;
    @FXML private Label label2;

    @FXML
    private void handleComputeButton1(ActionEvent e)
    {
        long n = Long.parseLong(this.textField1.getText());
        if (n <= 0)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("The value for n is invalid!");
            alert.showAndWait();
        }

        long result = MyTask.fibonacci(n);
        this.label1.setText("Result: " + Long.toString(result));
    }

    @FXML
    private void handleComputeButton2(ActionEvent e) {
        long n = Long.parseLong(this.textField2.getText());
        if (n <= 0)
        {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("ERROR");
            alert.setHeaderText("The value for n is invalid!");
            alert.showAndWait();
        }

        this.label2.setText("Processing...");

        Task<Long> task = new Task<Long>() {
            @Override
            protected Long call() throws Exception {
                Long result = MyTask.fibonacci(n);
                return result;
            }
        };
        task.setOnSucceeded(eventHandler -> {
            Long result = task.getValue();
            this.label2.setText("Result: " + Long.toString(result));
        });

        Thread t = new Thread(task);
        t.start();
    }
}
