module com.example.lecture9_demo {
    requires javafx.controls;
    requires javafx.fxml;

    opens FibonacciGUI to javafx.fxml;
    exports FibonacciGUI;
}