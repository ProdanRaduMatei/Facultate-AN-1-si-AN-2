package deadlock;

public class Deadlock {
    private String name;

    public Deadlock(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public synchronized void call(Deadlock call)
    {
        System.out.println(this.getName() + " is calling " + call.getName());
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // call another synchronized method
        call.call2Method(this);
    }

    public synchronized void call2Method(Deadlock call)
    {
        System.out.println(this.getName() + " has called " + call.getName());
    }

    public static void main(String[] args) {
        Deadlock caller1 = new Deadlock("Caller1");
        Deadlock caller2 = new Deadlock("Caller2");

        Thread thread1 = new Thread(new Runnable() {
            @Override
            public void run() {
                // this will get a lock on caller2
                // when calling call2Method, a lock will have to be got on caller1 (which is already locked by thread2)
                caller1.call(caller2);
            }
        });
        thread1.start();

        Thread thread2 = new Thread(new Runnable() {
            @Override
            public void run() {
                // this will get a lock on caller1
                // when calling call2Method, a lock will have to be got on caller2 (which is already locked by thread1)
                caller2.call(caller1);
            }
        });
        thread2.start();
    }
}
