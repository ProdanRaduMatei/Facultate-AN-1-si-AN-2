package producer_consumer;

class Consumer implements Runnable
{
    private BankAccount accout;
    private double amount;

    public Consumer(BankAccount account, double amount) {
        this.accout = account;
        this.amount = amount;
    }

    @Override
    public void run() {
        this.accout.withdraw(this.amount);
    }
}

class Producer implements Runnable
{
    private BankAccount accout;
    private double amount;

    public Producer(BankAccount accout, double amount) {
        this.accout = accout;
        this.amount = amount;
    }

    @Override
    public void run() {
        this.accout.deposit(this.amount);
    }
}

public class CommunicationConditions {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(0);
        int threadCount = 5;
        Thread[] threads = new Thread[threadCount];

        // create 3 producers and 2 consumers
        for (int i = 0; i < threadCount; i++)
        {
            if (i % 2 == 0)
                threads[i] = new Thread(new Producer(account, 50));
            else
                threads[i] = new Thread(new Consumer(account, 50));
        }
        for (int i = 0; i < threadCount; i++)
            threads[i].start();

        for (int i = 0; i < threadCount; i++) {
            try {
                threads[i].join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        System.out.println("Final balance: " + account.getBalance());
    }
}
