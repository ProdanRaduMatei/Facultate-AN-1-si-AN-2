package producer_consumer;

public class BankAccount {
    private double balance;

    public BankAccount(double balance) {
        this.balance = balance;
    }

    public BankAccount() {
        this(0);
    }

    public double getBalance() {
        return balance;
    }

    // synchronization problem
//    public void deposit(double amount)
//    {
//        System.out.println("Current balance: " + this.balance);
//        double temp = this.balance;
//        temp += amount;
//        try {
//            Thread.sleep(300); // while this thread sleeps, the second thread can access the balance
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        this.balance = temp;
//        System.out.println("Deposited: " + amount);
//    }
//
//    public void withdraw(double amount)
//    {
//        while (this.balance < amount)
//        {
//            System.out.println("Insufficient funds! Should be waiting...");
//            return;
//        }
//
//        double temp = this.balance;
//        temp = temp - amount;
//        try {
//            Thread.sleep(300);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        this.balance = temp;
//
//        System.out.println("Balance after withdrawal: " + this.balance);
//    }

    //---------------------------------------------------------------------------------------------------------------

//    // mutual exclusion using a "synchronized" method
//    public synchronized void deposit(double amount)
//    {
//        System.out.println("Current balance: " + this.balance);
//        double temp = this.balance;
//        temp += amount;
//        try {
//            Thread.sleep(300); // while this thread sleeps, the second thread can access the balance
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        this.balance = temp;
//        System.out.println("Balance after deposit: " + this.balance);
//    }
//
//    public synchronized void withdraw(double amount)
//    {
//        while (this.balance < amount)
//        {
//            System.out.println("Insufficient funds! Should be waiting...");
//            return;
//        }
//
//        double temp = this.balance;
//        temp = temp - amount;
//        try {
//            Thread.sleep(300);
//        } catch (InterruptedException e) {
//            e.printStackTrace();
//        }
//        this.balance = temp;
//
//        System.out.println("Balance after withdrawal: " + this.balance);
//    }

    //---------------------------------------------------------------------------------------------------------------
    // communication via conditions
    // producer notifies all consumers when something was deposited
    public synchronized void deposit(double amount)
    {
        System.out.println("Current balance: " + this.balance);
        double temp = this.balance;
        temp += amount;
        try {
            Thread.sleep(300); // while this thread sleeps, the second thread can access the balance
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.balance = temp;
        System.out.println("Balance after deposit: " + this.balance);
        notifyAll();
    }

    // consumer waits until someone notifies that a deposit was made
    public synchronized void withdraw(double amount)
    {
        System.out.println("Trying to withdraw...");
        while (this.balance < amount)
        {
            System.out.println("Insufficient funds! Waiting...");
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        double temp = this.balance;
        temp = temp - amount;
        try {
            Thread.sleep(300);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        this.balance = temp;

        System.out.println("Balance after withdrawal: " + this.balance);
    }
}
