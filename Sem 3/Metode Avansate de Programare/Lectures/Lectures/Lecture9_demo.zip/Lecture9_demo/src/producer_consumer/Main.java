package producer_consumer;

public class Main {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();

        // create Thread using a method
        Thread t1 = new Thread(() -> account.deposit(100));
        Thread t2 = new Thread(() -> account.deposit(50));

        t1.start();
        t2.start();

        try {
            t1.join();
            t2.join(); // the current thread (of the main program) will wait for both threads t1 and t2 to terminate
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // if the method "deposit" is not synchronized,
        // the result will be 50 or 100, not 150!
        System.out.println("Balance after deposits: " + account.getBalance());
    }
}
