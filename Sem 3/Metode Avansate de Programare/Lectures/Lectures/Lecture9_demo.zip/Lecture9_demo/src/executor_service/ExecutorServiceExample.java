package executor_service;

import java.util.*;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

// computes the sum of numbers from an array and adds it to a concurrent HashMap
class ArraySumWorker implements Runnable
{
    private ArrayList<Integer> array = new ArrayList<>();
    private ConcurrentHashMap<String, Integer> resultMap;
    private String name;

    public ArraySumWorker(ArrayList<Integer> array, ConcurrentHashMap<String, Integer> resultMap, String name) {
        this.array = array;
        this.resultMap = resultMap;
        this.name = name;
    }

    @Override
    public void run() {
        resultMap.put(name, array.stream()
                .reduce(0, (a, b) -> a + b));
    }
}

public class ExecutorServiceExample {
    public static ArrayList<Integer> generateArray(int size)
    {
        ArrayList<Integer> array = new ArrayList<>();

        // generate random array of fixed size
        Random rnd = new Random();
        for (int i = 0; i < size; i++)
            array.add(rnd.nextInt(1000));

        return array;
    }

    // compute all sums in a list of arrays using multiple threads
    public static ConcurrentHashMap<String, Integer>
            computeWithThreads(ArrayList<ArrayList<Integer>> arrayOfArrays)
    {
        ConcurrentHashMap<String, Integer> resultMap =
                new ConcurrentHashMap<>(arrayOfArrays.size());

        int i = 0;

        ArrayList<Thread> threads = new ArrayList<>();

        // create a thread for each array
        for ( ArrayList<Integer> integers : arrayOfArrays){

            String arrayName = "Array " + i;

            ArraySumWorker sumWorker =
                    new ArraySumWorker(integers, resultMap, arrayName);
            Thread thread = new Thread(sumWorker);
            threads.add(thread);
            i++;
        }

        // start all threads
        for (Thread thread : threads){
            thread.start();
        }

        // wait for all threads to finish
        for (Thread thread : threads){
            try {
                thread.join();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }

        return resultMap;
    }

    // compute all sums in a list of arrays using multiple threads, via an ExecutorService
    private static ConcurrentHashMap<String, Integer>
        computeWithExecutor(ArrayList<ArrayList<Integer>> arrayOfArrays){

        ConcurrentHashMap<String, Integer> resultMap =
                new ConcurrentHashMap<>(arrayOfArrays.size());

        ExecutorService executor =
                Executors.newFixedThreadPool(arrayOfArrays.size());
        int i = 0;
        for(ArrayList<Integer> integers : arrayOfArrays){
            String arrayName = "Array "+ i;
            ArraySumWorker sumWorker = new ArraySumWorker(integers, resultMap, arrayName);
            executor.execute(sumWorker);
            i++;
        }
        executor.shutdown(); // previously submitted tasks are executed and no new tasks are accepted

        try {
            // Blocks until all tasks have completed execution after a shutdown request, or the timeout occurs
            executor.awaitTermination(60, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }

        return resultMap;
    }

    public static void printSum(ConcurrentHashMap<String, Integer> sumMap)
    {
        List<String> mapKeys = Collections.list(sumMap.keys());
        // sort by array number
        Collections.sort(mapKeys, new Comparator<String>() {
            @Override
            public int compare(String o1, String o2) {
                String[] o1Array = o1.split(" ");
                String[] o2Array = o2.split(" ");
                Integer o1Int = Integer.parseInt(o1Array[1]);
                Integer o2Int = Integer.parseInt(o2Array[1]);
                return o1Int.compareTo(o2Int);
            }
        });
        for ( String s : mapKeys) {
            System.out.println(s + ": " + sumMap.get(s));
        }
    }

    public static void main(String[] args) {
        ArrayList<ArrayList<Integer>> arrayOfArrays = new ArrayList<>();

        for (int i = 0; i < 10; i++)
            arrayOfArrays.add(generateArray(35));

        // use threads
        long start = System.currentTimeMillis();
        ConcurrentHashMap<String, Integer> resultMap =
                computeWithThreads(arrayOfArrays);
        long end = System.currentTimeMillis();
        System.out.println("With threads - Result obtained in: " + (end  - start) + " milliseconds.");
        printSum(resultMap);

        // use executor
        start = System.currentTimeMillis();
        resultMap = computeWithExecutor(arrayOfArrays);
        end = System.currentTimeMillis();
        System.out.println("With ExecutorService - Result obtained in: " + (end  - start) + " milliseconds.");
        printSum(resultMap);
    }
}
