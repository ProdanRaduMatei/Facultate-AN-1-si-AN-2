package main;

import domain.Book;
import gui.BooksController;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;
import repository.*;
import service.BooksService;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.Properties;

public class Main extends Application {
    public static IRepository<Book, Integer> getRepository()
    {
        IRepository<Book, Integer> repo = null;

        try (FileReader fr = new FileReader("settings.properties"))
        {
            Properties props = new Properties();
            props.load(fr);

            String repoType = props.getProperty("repository");
            switch (repoType)
            {
                case "inmemory":
                    repo = new BookMemoryRepository();
                    try {
                        repo.add(new Book(1, "Author1", "Title1", 100));
                    } catch (DuplicateEntityException e) {
                        throw new RuntimeException(e);
                    }
                    break;
                case "textfile": {
                    String booksFile = props.getProperty("book_repository");
                    //repo = new BookFileRepository(booksFile);
                    repo = new GeneralTextFileRepository<>(booksFile, "domain.Book");
                    break;
                }
                case "binaryfile": {
                    String booksFile = props.getProperty("book_repository");
                    repo = new BookBinaryFileRepository(booksFile);
                    break;
                }
                case "database":
                    String booksTable = props.getProperty("book_repository");
                    repo = new BookDatabaseRepository(booksTable);
                    break;
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

        return repo;
    }

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage stage) throws Exception {
        IRepository<Book, Integer> repo = getRepository();
        BooksService service = new BooksService(repo);
        BooksController controller = new BooksController(service);

        FXMLLoader loader = new FXMLLoader(getClass().getResource("/gui/BooksGUI.fxml"));
        loader.setController(controller);
        Scene scene = new Scene(loader.load());
        stage.setScene(scene);
        stage.show();
    }
}