package repository;

import domain.Identifiable;
import org.sqlite.SQLiteDataSource;

import java.sql.*;

public abstract class DatabaseRepository<T extends Identifiable<U>, U>
        extends MemoryRepository<T, U> {

        protected String tableName;

        public DatabaseRepository(String tableName) {
                this.tableName = tableName;
                this.getData();
        }

        private static final String URL = "jdbc:sqlite:data/test.db";

        protected Connection conn = null;

        protected void openConnection()
        {
                SQLiteDataSource ds = new SQLiteDataSource();
                ds.setUrl(URL);
                try {
                        if (conn == null || conn.isClosed())
                                conn = ds.getConnection();
                } catch (SQLException e) {
                        throw new RuntimeException(e);
                }
        }

        protected void closeConnection()
        {
                try {
                        conn.close();
                } catch (SQLException e) {
                        throw new RuntimeException(e);
                }
        }

        public abstract void getData();
}
