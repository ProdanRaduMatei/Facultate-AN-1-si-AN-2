package repository;

import domain.Book;
import domain.Identifiable;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;

public class GeneralTextFileRepository <T extends Identifiable, U>
        extends MemoryRepository<T, U> {
    protected String filename;
    private String entityName;

    public GeneralTextFileRepository(String filename, String entityName) {
        this.filename = filename;
        this.entityName = entityName;
        this.readFromFile();
    }

    public void readFromFile()
    {
        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line = null;
            while ((line = br.readLine()) != null)
            {
                Class className = Class.forName(entityName);
                T newObject = (T) className.getConstructor(String.class).newInstance(line);
                elems.add(newObject);
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        } catch (IOException e) {
            throw new RuntimeException(e);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        } catch (InvocationTargetException e) {
            throw new RuntimeException(e);
        } catch (InstantiationException e) {
            throw new RuntimeException(e);
        } catch (IllegalAccessException e) {
            throw new RuntimeException(e);
        } catch (NoSuchMethodException e) {
            throw new RuntimeException(e);
        }
    }

    //public void writeToFile();

    @Override
    public void add(T elem) throws DuplicateEntityException
    {
        super.add(elem);
        //this.writeToFile();
    }
}
