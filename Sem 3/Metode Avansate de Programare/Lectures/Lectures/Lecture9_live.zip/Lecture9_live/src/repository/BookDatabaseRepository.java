package repository;

import domain.Book;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class BookDatabaseRepository extends DatabaseRepository<Book, Integer> {
    public BookDatabaseRepository(String tableName) {
        super(tableName);
    }

    @Override
    public void getData() {
        super.openConnection();
        String sql = "SELECT * FROM " + tableName + ";";
        try (PreparedStatement ps = conn.prepareStatement(sql)) {
            ResultSet rs = ps.executeQuery();
            while (rs.next())
            {
                Book b = new Book(rs.getInt("id"),
                        rs.getString("authors"),
                        rs.getString("title"),
                        rs.getInt("pages"));
                super.add(b);
            }

        } catch (SQLException e) {
            throw new RuntimeException(e);
        } catch (DuplicateEntityException e) {
            throw new RuntimeException(e);
        }
        super.closeConnection();
    }

    @Override
    public void add(Book book) throws DuplicateEntityException
    {
        super.openConnection();
        super.add(book);
        String sql = "INSERT INTO " + tableName + " VALUES (?,?,?,?);";
        try (PreparedStatement ps = conn.prepareStatement(sql))
        {
            ps.setInt(1, book.getId());
            ps.setString(2, book.getAuthor());
            ps.setString(3, book.getTitle());
            ps.setInt(4, book.getNumberOfPages());
            ps.executeUpdate();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        super.closeConnection();
    }
}