package gui;

import domain.Book;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.KeyEvent;
import service.BooksService;

import java.util.ArrayList;
import java.util.stream.Collectors;

public class BooksController {
    private BooksService service;

    public BooksController(BooksService service) {
        this.service = service;
    }

    @FXML
    private ListView<Book> booksListView;

    @FXML
    private TextField searchTextField;

    void populateList()
    {
        ObservableList<Book> booksList = FXCollections.observableArrayList((ArrayList<Book>)service.getAll());
        booksListView.setItems(booksList);
    }

    public void initialize()
    {
        populateList();
    }

    @FXML
    void searchOnType(KeyEvent event) {
        String searchText = searchTextField.getText();
        ArrayList<Book> books = (ArrayList<Book>)service.getAll();
        ArrayList<Book> filteredBooks = (ArrayList<Book>) books.stream()
                .filter(b -> b.getTitle().toUpperCase().contains(searchText.toUpperCase()) ||
                        b.getAuthor().toUpperCase().contains(searchText.toUpperCase()))
                .collect(Collectors.toList());

        if (searchText.equals(""))
            populateList();
        else
        {
            ObservableList<Book> filteredBooksList = FXCollections.observableArrayList(filteredBooks);
            booksListView.setItems(filteredBooksList);
        }
    }
}
