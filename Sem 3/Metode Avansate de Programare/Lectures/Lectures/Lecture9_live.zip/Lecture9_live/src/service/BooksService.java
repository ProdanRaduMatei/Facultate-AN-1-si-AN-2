package service;

import repository.DuplicateEntityException;
import repository.IRepository;
import domain.Book;

public class BooksService {
    private IRepository<Book, Integer> repo;

    public BooksService(IRepository<Book, Integer> repo) {
        this.repo = repo;
    }

    public void add(int id, String authors, String title, int noPages) throws DuplicateEntityException {
        Book book = new Book(id, authors, title, noPages);
        this.repo.add(book);
    }

    public Iterable<Book> getAll()
    {
        return repo.getAll();
    }
}
