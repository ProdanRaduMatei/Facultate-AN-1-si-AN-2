package ui;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

import java.io.IOException;

public class Controller {

    @FXML
    private Button MargheritaButton;

    @FXML
    private Button CapriociossaButton;

    @FXML
    private Button ProsciuttoButton;

    @FXML
    void CapriociossaButtonHandler(ActionEvent event) throws IOException {

    }

    @FXML
    void MargheritaButtonHandler(ActionEvent event) throws IOException {

    }

    @FXML
    void ProsciuttoButtonHandler(ActionEvent event) throws IOException {

    }
}
