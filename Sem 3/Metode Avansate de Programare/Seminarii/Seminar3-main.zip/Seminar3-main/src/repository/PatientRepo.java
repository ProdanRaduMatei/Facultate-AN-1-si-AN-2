package src.repository;

import src.domain.Patient;

public class PatientRepo extends MemoryRepo<Patient,String> {

}
