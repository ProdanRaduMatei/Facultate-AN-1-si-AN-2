package repository;

import domain.Patient;

public class PatientRepo extends MemoryRepo<Patient,String> {

}
