package repository;

import domain.Doctor;

public class DoctorRepo extends MemoryRepo<Doctor,Integer>{

}
