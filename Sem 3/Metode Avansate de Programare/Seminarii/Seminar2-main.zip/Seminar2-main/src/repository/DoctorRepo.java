package src.repository;

import src.domain.Doctor;

public class DoctorRepo extends MemoryRepo<Doctor,Integer>{

}
