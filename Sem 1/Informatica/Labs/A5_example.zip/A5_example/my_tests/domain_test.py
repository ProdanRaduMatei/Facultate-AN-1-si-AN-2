import unittest


class PersonTest(unittest.TestCase):
    def testInit(self):
        self.assertFalse(False)
