class PersonRepository:  # Plane, Department
    # TODO: getters and setters for the properties
    # TODO: CRUD operations
    # TODO: you should have one filter function
    # TODO: you should have one sort function
    # TODO: you should have one back track

    pass


class PersonRepositoryRepository:  # Airport, Hospital
    # TODO: getters and setters for the properties
    # TODO: call the filter function for a Plane/Department identified by ID
    # TODO: call the sort function for a Plane/Department identified by ID
    # TODO: call the back track function for a Plane/Department identified by ID

    def example(self):
        return