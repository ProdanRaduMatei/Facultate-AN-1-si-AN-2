n = int(input("n= "))
s = 0
for i in range (1, int(n / 2) + 1):
    if n % i == 0:
        s += i
print(s)
