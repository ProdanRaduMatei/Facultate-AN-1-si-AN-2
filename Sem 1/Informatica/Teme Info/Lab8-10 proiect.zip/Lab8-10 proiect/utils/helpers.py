def checkType(number):
    if number >=1:
        return 1
    else:
        return 0


def checkColor(color):
    if color == "r" or color == "b" or color == "g" or color == "y" or color == "m":
        return True
    else:
        return False