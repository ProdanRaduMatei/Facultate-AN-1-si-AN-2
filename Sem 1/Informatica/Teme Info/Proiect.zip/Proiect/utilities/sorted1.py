def SortAllValues(score_list): # this function sorts the list
    for i in range(0, len(score_list) - 1): # goes through the list
        for j in range(i + 1, len(score_list)): # goes through the list
            if (score_list[i] > score_list[j]): # checks if the scores are ordered
                aux = score_list[i]
                score_list[i] = score_list[j]
                score_list[j] = aux
    return score_list # returns the list