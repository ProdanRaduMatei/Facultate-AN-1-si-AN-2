def PrintArray(score_list): # this function prints an array
    print(score_list) # prints the array