import domain.footballteam as xm


class Repository:
    def __init__(self, List=None):
        self.__List = []
        if List is not None:
            for Team in List:
                if isinstance(Team, xm.Xs) and self.__isunique(Team.country):
                    self.__List.append(Team)
                else:
                    raise ValueError("Not a Team!")

    def __isunique(self, country):
        """Check if the name of the country is unique
        :param index:
        :type index: int
        :return:
        :rtype: bool
        """
        for Team in self.__List:
            if Team.country == country:
                return False
        return True

    def addTeam(self, country, numberofgoals):
        """
        Add a new team.
        :param country: country name
        :param numberofgoals: number of goals
        :return: Team
        """
        if not self.__isunique(country):
            self.__List.append(country.teams(country, numberofgoals))
        else:
            raise ValueError("Country is not correct.")
    
    def getNrOfMaximumGoals(self):
        max = -1
        for team in self.__List:
            if team.numberofgoals() > max:
                max = team.numberofgoals()
        return Repository(filter(lambda team: team.numberofgoals() == max, self.__List))
    
    def getTeamsWithScore15(self):
        co = self.__List.copy()
        for i in range(0, len(co) - 1):
            for j in range(i + 1, len(co)):
                if co[i].numberofgoals > co[j].numberofgoals:
                    co[i].numberofgoals, co[j].numberofgoals = co[j].numberofgoals, co[i].numberofgoals
        return Repository(filter(lambda team: team.numberofgoals < 15, self.__List))

    def Sortscore(self):
        return Repository(sorted(self.__List, key = lambda Team: Team.numberofgoals))
    
    def getAll(self):
        return Repository(sorted(filter(lambda Team: len(Team.country()) < 15, self.__List)))


    def __repr__(self):
        return str(self.__List)

