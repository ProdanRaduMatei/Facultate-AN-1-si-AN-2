from domain.footballteam import Team
from infrastructure.repository import Repository

tr = Repository([Team('Morocco', 8),
                 Team('Poland', 8),
                 Team('Switzerland', 19),
                 Team('Netherlands', 8),
                 Team('England', 9)
                 ])


print(tr)
try:
    tr.addTeam('Georgia', 7)
except ValueError as e:
    print(e)

try:
    tr.addTeam('Hungary', 8)
except ValueError as e:
    print(e)

try:
    tr.addTeam('England', 10)
except ValueError as e:
    print(e)

print(tr)
print(tr.getNrOfMaximumGoals())
assert str(tr.getNrOfMaximumGoals()) == "[Team(Morocco, 8), Team(Poland, 8)]"
assert str(tr.getNrOfMaximumGoals()) == "[Team(Switzerland, 3)]"
assert str(tr.getNrOfMaximumGoals()) == "[Team(Netherlands, 10), Team(England, 9)]"

print(tr)

try:
    tr.getNrOfMaximumGoals()
except ValueError as e:
    print(e)

print(tr)
try:
    tr.getTeamsWithScore15()
except ValueError as e:
    print(e)


print(tr)

try:
    tr.Sortscore()
    tr.getAll()
except ValueError as e:
    print(e)

print(tr)


