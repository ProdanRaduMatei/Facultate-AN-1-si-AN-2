class FootballTeam:
    def __init__(self, country, numberofgoals):
        self.__name = country
        if numberofgoals >= 0:
            self.__score = numberofgoals
        else:
            raise ValueError("numberofgoals is not correct!")


    @property
    def country(self):
        return self.__name
    @property
    def numberofgoals(self):
        return self.__score

    @country.setter
    def country(self, other_name):
        self.__name = other_name
    
    @numberofgoals.setter
    def numberofgoals(self, other_score):
        self.__score = other_score

    def __repr__(self):
        return f"Team({self.__name}, {self.__score})"

    def __str__(self):
        return self.__repr__()

    def __eq__(self, other):
        return self.__name == other.__score or self.__score == other.__score
