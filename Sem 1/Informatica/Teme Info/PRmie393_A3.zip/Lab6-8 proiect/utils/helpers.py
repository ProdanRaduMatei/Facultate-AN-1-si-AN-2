def checkColor(color):
    if color == "red" or color == "blue" or color == "green" or color == "yellow" or color == "magenta":
        return True
    else:
        return False