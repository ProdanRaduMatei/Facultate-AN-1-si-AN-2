from email.errors import MessageError

def Message(): # this function prints the menu
    print("Insert 0 if you want to end the program.")
    print("Insert 1 if you want to add the result of a new participant to the array.")
    print("Insert 2 if you want to modify the scores in the array.")
    print("Insert 3 if you wnat to get the participants with scores having some properties.")
    print("Insert 4 if you want to obtain different characteristics of participants.")
    print("Insert 5 if you want to filter the values.")
    print("Insert 6 if you want to undo the last operation that modified the array.")
    print("Insert 7 if you want to print the array.")
    print("Insert 8 if you want to run all tests.")
