def ReadCase(): # this function reads the case
    case = (int(input("Case = "))) # reads the case
    return case # return the case