def ReadIndex(): # this function reads the index
    index = (int(input("Index = "))) # reads the index
    return index # returns the index