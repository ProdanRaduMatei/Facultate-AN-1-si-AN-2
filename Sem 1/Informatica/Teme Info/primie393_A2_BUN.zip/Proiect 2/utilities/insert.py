def Insert(score_list, index, value): # this function inserts a value at an index
    score_list.insert(index, value) # inserts the value at the index
    return score_list # returns the list

#TestInsert()