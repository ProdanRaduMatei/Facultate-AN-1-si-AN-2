def ReadValue(): # this function reads a value
    value = (int(input("Value = "))) # reads a value
    return value # returns the value