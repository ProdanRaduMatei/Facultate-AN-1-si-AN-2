def RemoveElement(score_list, index): #this function removes a score at a certain index
    del score_list[index] # removes the score at the index
    return score_list # return the list

#TestRemoveElement()