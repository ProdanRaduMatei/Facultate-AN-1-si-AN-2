def Replace(score_list, index, new_value): # this function replaces the score at an index with a value
    score_list[index] = new_value # replaces the score at index with a value
    return score_list # returns the list

#TestReplace()