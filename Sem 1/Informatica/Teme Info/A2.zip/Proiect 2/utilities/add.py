def Add(score_list, value): # this function adds a value to the end of the list
    score_list.append(value) # adds the value to the list
    return score_list # returns the list


#TestAdd()

#print(Add([], 0))
#print(Add([0], 1))
#print(Add([], 0))