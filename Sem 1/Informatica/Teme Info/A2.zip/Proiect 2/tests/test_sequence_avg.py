from src.sequence_avg import SequenceAvg

def TestSequenceAvg():
    score_list = [5]
    SequenceAvg(score_list, 0, 0)
    assert score_list == [5]
    
    try:
        SequenceAvg(score_list, 0, 0)
        assert True
    except ValueError:
        assert False
    
    try:
        SequenceAvg(score_list, 11, 100)
        assert False
    except ValueError:
        assert True
    
    try:
        SequenceAvg(score_list, 'a', 'b')
        assert False
    except ValueError:
        assert True