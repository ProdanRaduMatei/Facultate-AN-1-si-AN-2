from src.add import Add

def TestAdd():
    score_list = []
    Add(score_list, 5)
    assert score_list == [5]
    
    try:
        Add(score_list, 6)
        assert True
    except ValueError:
        assert False
    
    try:
        Add(score_list, 11)
        assert False
    except ValueError:
        assert True
    
    try:
        Add(score_list, 'a')
        assert False
    except ValueError:
        assert True
