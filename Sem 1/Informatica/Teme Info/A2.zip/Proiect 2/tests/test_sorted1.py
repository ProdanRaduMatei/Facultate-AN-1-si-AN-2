from src.sorted1 import SortAllValues

def TestSortAllValues():
    score_list = [5, 4, 3, 2, 1]
    assert SortAllValues(score_list) == [4, 3, 2, 1, 0]
    score_list = [1, 2, 3, 4, 5]
    assert SortAllValues(score_list) == [0, 1, 2, 3, 4]
    score_list = [1, 2, 3, 4, 5, 6]
    assert SortAllValues(score_list) == [0, 1, 2, 3, 4, 5]
    score_list = [1, 2, 3, 4, 5, 6, 7]
    assert SortAllValues(score_list) == [0, 1, 2, 3, 4, 5, 6]
    score_list = [1, 2, 3, 4, 5, 6, 7, 8]
    assert SortAllValues(score_list) == [0, 1, 2, 3, 4, 5, 6, 7]
    score_list = [1, 2, 3, 4, 5, 6, 7, 8, 9]
    assert SortAllValues(score_list) == [0, 1, 2, 3, 4, 5, 6, 7, 8]
    score_list = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
    assert SortAllValues(score_list) == [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]