from src.filter_greater import FilterGreater

def TestFilterGreater():
    score_list = [5]
    FilterGreater(score_list, 5)
    assert score_list == [5]
    
    try:
        FilterGreater(score_list, 6)
        assert True
    except ValueError:
        assert False
    
    try:
        FilterGreater(score_list, 11)
        assert False
    except ValueError:
        assert True
    
    try:
        FilterGreater(score_list, 'a')
        assert False
    except ValueError:
        assert True
