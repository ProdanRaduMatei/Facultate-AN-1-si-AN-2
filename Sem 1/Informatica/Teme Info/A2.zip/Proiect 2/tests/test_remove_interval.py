from src.remove_interval import RemoveInterval

def TestRemoveInterval():
    score_list = [5, 6, 7]
    RemoveInterval(score_list, 0, 1)
    assert score_list == [7]
    
    try:
        RemoveInterval(score_list, 0, 0)
        assert True
    except ValueError:
        assert False
    
    try:
        RemoveInterval(score_list, 11, 100)
        assert False
    except ValueError:
        assert True
    
    try:
        RemoveInterval(score_list, 'a', 'b')
        assert False
    except ValueError:
        assert True