from src.sequence_min import SequenceMin

def TestSequenceMin():
    score_list = [5]
    SequenceMin(score_list, 0, 0)
    assert score_list == [5]
    
    try:
        SequenceMin(score_list, 0, 0)
        assert True
    except ValueError:
        assert False
    
    try:
        SequenceMin(score_list, 11, 100)
        assert False
    except ValueError:
        assert True
    
    try:
        SequenceMin(score_list, 'a', 'b')
        assert False
    except ValueError:
        assert True