from src.less import Less

def TestLess():
    score_list = [5]
    Less(score_list, 6)
    assert score_list == [5]
    
    try:
        Less(score_list, 9)
        assert True
    except ValueError:
        assert False
    
    try:
        Less(score_list, 1)
        assert False
    except ValueError:
        assert True
    
    try:
        Less(score_list, 'a')
        assert False
    except ValueError:
        assert True