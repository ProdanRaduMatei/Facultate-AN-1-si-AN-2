from src.remove_element import RemoveElement

def TestRemoveElement():
    score_list = [5, 6]
    RemoveElement(score_list, 0)
    assert score_list == [6]
    
    try:
        RemoveElement(score_list, 0)
        assert True
    except ValueError:
        assert False
    
    try:
        RemoveElement(score_list, 11)
        assert False
    except ValueError:
        assert True
    
    try:
        RemoveElement(score_list, 'a')
        assert False
    except ValueError:
        assert True