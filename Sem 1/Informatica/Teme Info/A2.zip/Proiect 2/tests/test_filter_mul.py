from src.filter_mul import FilterMul

def TestFilterMul():
    score_list = [2]
    FilterMul(score_list, 2)
    assert score_list == [2]
    
    try:
        FilterMul(score_list, 2)
        assert True
    except ValueError:
        assert False
    
    try:
        FilterMul(score_list, 3)
        assert False
    except ValueError:
        assert True
    
    try:
        FilterMul(score_list, 'a')
        assert False
    except ValueError:
        assert True
