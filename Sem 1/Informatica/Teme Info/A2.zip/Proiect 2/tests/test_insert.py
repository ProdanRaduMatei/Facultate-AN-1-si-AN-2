from src.insert import Insert

def TestInsert():
    score_list = []
    Insert(score_list, 0, 5)
    assert score_list == [5]
    
    try:
        Insert(score_list, 0, 2)
        assert True
    except ValueError:
        assert False
    
    try:
        Insert(score_list, 1, 11)
        assert False
    except ValueError:
        assert True
    
    try:
        Insert(score_list, 0, 'a')
        assert False
    except ValueError:
        assert True