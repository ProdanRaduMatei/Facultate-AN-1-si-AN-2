from sorted2 import SortValuesGreater

def TestSortValuesGreater():
    score_list = [5]
    SortValuesGreater(score_list, 1)
    assert score_list == [5]
    
    try:
        SortValuesGreater(score_list, 2)
        assert True
    except ValueError:
        assert False
    
    try:
        SortValuesGreater(score_list, 11)
        assert False
    except ValueError:
        assert True
    
    try:
        SortValuesGreater(score_list, 'a')
        assert False
    except ValueError:
        assert True
