from src.sequence_mul import SequenceMul

def TestSequenceMul():
    score_list = [5]
    SequenceMul(score_list, 1, 0, 0)
    assert score_list == [5]
    
    try:
        SequenceMul(score_list, 5, 0, 0)
        assert True
    except ValueError:
        assert False
    
    try:
        SequenceMul(score_list, 2, 11, 100)
        assert False
    except ValueError:
        assert True
    
    try:
        SequenceMul(score_list, 'a', 'b', 'c')
        assert False
    except ValueError:
        assert True