from tests.students_test import runAllTests as runAllStudentTests
from tests.helper_test import runAllTests as runAllHelperTests


def runAllTests():
    runAllStudentTests()
    runAllHelperTests()
