from ui import console

console.start()
