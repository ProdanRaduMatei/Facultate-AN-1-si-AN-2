def checkGrade(grade):
    return 0 < grade < 11
