from ui import console
from tests import runAllTests

runAllTests()
print("All tests run successfully!")
console.start()
