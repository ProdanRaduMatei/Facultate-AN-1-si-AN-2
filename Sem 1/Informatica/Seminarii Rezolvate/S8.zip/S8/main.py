from ui import console


print("All tests run successfully!")
console.start()
