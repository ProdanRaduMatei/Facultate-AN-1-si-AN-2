import run_tests
import data_examples


run_tests.run_all()
print("\n")
data_examples.run_all()
print("\n")
