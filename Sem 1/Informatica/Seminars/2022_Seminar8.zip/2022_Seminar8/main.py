'''
Created on 25 Nov 2022

@author: cchir
'''

from ui.bookui import BookUI
from application.bookCtrl import BookController
from infrastructure.bookRepo import BookRepository
from infrastructure.authorRepo import AuthorRepository

from domain.book import Book
from domain.author import Author

bRepo = BookRepository()
aRepo = AuthorRepository()
ctrl = BookController(bRepo, aRepo)

a1 = Author(1, "Paul S")
a2 = Author(2, "Ana S")

b1 = Book(10, a1, "Far away", 37.50)
ctrl.addBook(b1)

b2 = Book(20, a2, "Europe", 25.50)
ctrl.addBook(b2)

bookUI = BookUI(ctrl)
bookUI.start()

