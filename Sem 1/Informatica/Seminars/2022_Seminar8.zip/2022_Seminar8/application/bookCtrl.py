'''
Created on 25 Nov 2022

@author: cchir
'''

class BookController(object):
    '''
    classdocs
    '''


    def __init__(self, brepo, arepo):
        '''
        Constructor
        '''
        self.__bookRepo = brepo
        self.__authorRepo = arepo
        
    def getAllBooks(self):
        return self.__bookRepo.getRepo()
    
    def getAllAuthors(self):
        return self.__authorRepo.getRepo()
    
    def addBook(self, book):
        self.__bookRepo.addBook(book)
        if self.__authorRepo.find(book.getAuthor()) < 0:
            self.__authorRepo.addAuthor(book.getAuthor())
            
    def getAuthorById(self, aid):
        return self.__authorRepo.getAuthorById()
    
    def getBookByWord(self, word):
        return self.__bookRepo.getBookByWord(word)