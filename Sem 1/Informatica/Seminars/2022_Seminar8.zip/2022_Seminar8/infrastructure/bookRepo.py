'''
Created on 25 Nov 2022

@author: cchir
'''

class BookRepository(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        self.__data = []
        
    def sizeRepo(self):
        return len(self.__data)
    
    def getRepo(self):
        return self.__data
    
    def addBook(self, book):
        self.__data.append(book)
        
    def sortBooksByPrice(self):
        self.__data.sort(key = lambda x: x.getPrice())
        
    def getBookByWord(self, word):
        lst = []
        for i in self.__data:
            if i.getTitle().find(word):
                lst.append(i)
        return lst