'''
Created on 25 Nov 2022

@author: cchir
'''

class AuthorRepository(object):
    '''
    classdocs
    '''


    def __init__(self):
        '''
        Constructor
        '''
        self.__data = []
        
    def sizeRepo(self):
        return len(self.__data)
    
    def getRepo(self):
        return self.__data
    
    def addAuthor(self, author):
        self.__data.append(author)
    
    def find(self, author):
        for i in range(len(self.__data)):
            if self.__data[i].getId() == author.getId():
                return i
        return -1
    
    def getAuthorById(self, aid):
        for i in range(len(self.__data)):
            if self.__data[i].getId() == aid:
                return self.__data[i]
            
            