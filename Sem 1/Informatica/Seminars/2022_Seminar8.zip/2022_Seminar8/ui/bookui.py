'''
Created on 25 Nov 2022

@author: cchir
'''

from domain.author import Author
from domain.book import Book

class BookUI(object):
    '''
    classdocs
    '''


    def __init__(self, ctrl):
        '''
        Constructor
        '''
        self.__ctrl = ctrl
    
    @staticmethod
    def printMenu():
        msg = "Book Menu: \n"
        msg += "\t 1 - View book list \n"
        msg += "\t 2 - View author list \n"
        msg += "\t ***Book Submenu*** \n"
        msg += "\t 3 - Add book \n"
        msg += "\t ****** \n"
        msg += "\t 0 - Exit \n"
        print(msg)
        
    @staticmethod
    def readAuthor():
        id = int(input("Author id:"))
        name = input("Author name:")
        return Author(id, name)
        
    def readBook(self):
        code = int(input("Book code:"))
        title= input("Book title:")
        existingAuthor = input("Existing auhor? Y/N")
        author = None
        if existingAuthor == "Y":
            aid = int(input("Author id:"))
            author = self.__ctrl.getAuthorById(aid)
        else:
            author = BookUI.readAuthor()
        try:
            price = float(input("Book price:"))
        except:
            price = 0
        return Book(code, author, title, price)
    
    def printBookList(self):
        print("Book list is:")
        for elem in self.__ctrl.getAllBooks():
            print(elem)
    
    def printAuthorList(self):
        print("Author list is:")
        for elem in self.__ctrl.getAllAuthors():
            print(elem)
            
    def getBookByWord(self):
        word = input("Word is: ")
        lst = self.__ctrl.getBookByWord(word)
        if lst != []:
            for i in lst:
                print(i)
        else:
            print("Nothing found")
        
    def start(self):
        while True:
            BookUI.printMenu()
            option = input("Your option:")
            if option == "1":
                self.printBookList()
            elif option == "2":
                self.printAuthorList()
            elif option == "3":
                book = self.readBook()
                self.__ctrl.addBook(book)
            elif option == "4":
                BookUI.getBookByWord()
            elif option == "0":
                print("Good bye...")
                break
            else:
                print("Option does not exist!")
                
            
        
        
        