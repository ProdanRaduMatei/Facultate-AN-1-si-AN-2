'''
Created on 25 Nov 2022

@author: cchir
'''

class Author(object):
    '''
    classdocs
    '''


    def __init__(self, id, name):
        '''
        Constructor
        '''
        self.__id = id
        self.__name = name
        
    def getId(self):
        return self.__id
    
    def setId(self, id):
        self.__id = id
        
    def getName(self):
        return self.__name
        
    def setName(self, name):
        self.__name = name
        
    def __str__(self):
        return "Author: " + self.__name
    
    