'''
Created on 25 Nov 2022

@author: cchir
'''

class Book(object):
    '''
    classdocs
    '''


    def __init__(self, code, author, title, price):
        '''
        Constructor
        '''
        self.__code = code
        self.__author = author
        self.__title = title
        self.__price = price
        
    def getCode(self):
        return self.__code
    
    def setCode(self, code):
        self.__code = code
        
    def getAuthor(self):
        return self.__author
    
    def setAuthor(self, a):
        self.__author = a
        
    def getTitle(self):
        return self.__title
    
    def setTitle(self, t):
        self.__title = t
        
    def getPrice(self):
        return self.__price
    
    def setPrice(self, p):
        self.__price = p
        
    def __str__(self):
        return str(self.__code) + " - " + str(self.__author) + ", " + self.__title + " (" + str(self.__price) + " RON)"
        
        