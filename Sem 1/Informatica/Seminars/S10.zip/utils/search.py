def sequentialSearchUnordered(listOfValues, searchedValue):
    """
    seminar 9. ii. 1.
    Searching for a given value in an unordered list using sequential search.
    Worst case complexity: O(n)
    :param listOfValues:
    :param searchedValue:
    :return: first position of the searched element
    :rtype: int
    """
    if len(listOfValues) == 0:
        raise ValueError
    else:
        for i in range(len(listOfValues)):
            if listOfValues[i] == searchedValue:
                return i
        return -1


def sequentialSearchOrdered(listOfValues, searchedValue):
    """
    seminar 9. ii. 1.
    Searching for a given value in an ordered list using sequential search.
    Worst case complexity: O(n)
    :param listOfValues:
    :param searchedValue:
    :return: first position of the searched element
    :rtype: int
    """
    if len(listOfValues) == 0:
        raise ValueError
    else:
        for i in range(len(listOfValues)):
            if listOfValues[i] == searchedValue:
                return i
            elif listOfValues[i] > searchedValue:
                break
        return -1


def binarySearch(listOfValues, searchedValue, startIndex=None, endIndex=None):
    """
    seminar 9. ii. 2.
    Searching for a given value in an ordered list using binary search.
    Worst case complexity: O(log_2 n)
    :param listOfValues:
    :param searchedValue:
    :return: first position of the searched element
    :rtype: int
    """
    if startIndex is None:
        startIndex = 0
    if endIndex is None:
        endIndex = len(listOfValues) - 1
    if startIndex > endIndex:
        return -1
    else:
        middle = (startIndex + endIndex) // 2
    if searchedValue == listOfValues[middle]:
        return middle
    elif searchedValue < listOfValues[middle]:
        # calling binary search to the first half of the list
        return binarySearch(listOfValues, searchedValue, startIndex, middle - 1)
    else:
        # calling binary search to the second half of the list
        return binarySearch(listOfValues, searchedValue, middle + 1, endIndex)


def myFilter(listOfValues, criterion):
    """
    Filter elements of the list based on the given condition
    :param listOfValues:
    :param criterion: function having one parameter defining the condition of inclusion of a value in the result list
    :type: callable (a reference to a function or a lambda expression)
    :return: the filtered list
    :rtype: list
    """
    if len(listOfValues)==0:
        return []
    else:
        if criterion(listOfValues[0]):
            return [listOfValues[0]] + myFilter(listOfValues[1:], criterion)
        return myFilter(listOfValues[1:], criterion)


def inBuiltFilter(listOfValues, criterion):
    """
    Filter elements of the list based on the given condition using Python's in-built function
    :param listOfValues:
    :param criterion: function having one parameter defining the condition of inclusion of a value in the result list
    :type: callable (a reference to a function or a lambda expression)
    :return: the filtered list
    :rtype: list
    """
    return list(filter(criterion, listOfValues))
