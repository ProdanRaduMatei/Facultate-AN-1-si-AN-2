'''

@author: cami
'''
from ui.console import run

run()