'''
Created on 15 Sep 2017

@author: cami
'''
import ui.console

ui.console.run()

