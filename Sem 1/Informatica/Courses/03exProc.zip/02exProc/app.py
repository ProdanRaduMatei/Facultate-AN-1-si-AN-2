'''
Created on 7 Sep 2017

@author: cami
'''


def test_gcd():
    #test function for gcd
    assert gcd(14,21) == 7
    assert gcd(24, 9) == 3
    assert gcd(3, 5) == 1
    assert gcd(0, 3) == 3
    assert gcd(5, 0) == 5

    '''
    Descr: computes the gcd of 2 natural numbers    
    Data: a, b
    Precondition: a, b - natural numbers
    Results: res
    Postcondition:res=(a,b)  
    '''
def gcd(a, b):
    if (a == 0):
        if (b == 0):
            return -1   # a == b == 0
        else:
            return b    # a == 0, b != 0
    else:
        if (b == 0):    # a != 0, b == 0
            return a
        else:           # a != 0, b != 0
            while (a != b):
                if (a > b):
                    a = a - b
                else:
                    b = b - a
            return a    # a == b



def test_sum():
    assert sum([2, 3], [4, 5]) == [22, 15]
    assert sum([1, 4], [1, 4]) == [1, 2]
    assert sum([1, 2], [1, 2]) == [1, 1]
    
    
    '''
    Descr: computes the sum of two rational numbers    
    Data: r1, r2
    Precondition: r1, r2 - rational numbers 
    Results: rs
    Postcondition:rs - rational number, rs = r1 + r2  
    '''
def sum(r1, r2):
    denominator = r1[0] * r2[1] + r1[1] * r2[0]
    nominator = r1[1] * r2[1]
    divisor = gcd(denominator, nominator)
    rs = [denominator / divisor, nominator / divisor]
    return rs 
        

def readRational():
    denom = int(input("denominator = "))
    nom = int(input("nominator = "))
    while (nom == 0):
        print("nominotr must be different to 0...give a new value")
        nom = int(input("nominator = "))
    denom = denom / gcd(denom, nom)
    nom = nom / gcd(denom, nom)
    return [denom, nom]

def run():
    finish = False
    r_sum = [0, 1]
    while (not finish):
        r = readRational()
        if (r[0] == 0):
            finish = True
        else:
            r_sum = sum(r_sum, r)
    print(r_sum)
    
    
        
    
# run all tests by invoking the test function
test_gcd()
test_sum()

#main program
run()




    