#include <stdio.h>

int main(int argc, char *argv[])
{
	int n;

	printf("Introduceti valoarea lui n: ");
	scanf("%d", &n);

	printf("Valoare lui n este: %d\n",n);
	return 0;
}

