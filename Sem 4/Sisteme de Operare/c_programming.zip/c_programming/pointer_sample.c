#include <stdio.h>

int main() {
    int num = 10;
    char ch = 'A';
    float f = 3.14;

    int *ptr_int = &num;
    char *ptr_char = &ch;
    float *ptr_float = &f;

    printf("Valoarea lui num: %d, Adresa lui num: %p\n", num, &num);
    printf("Valoarea lui ch: %c, Adresa lui ch: %p\n", ch, &ch);
    printf("Valoarea lui f: %f, Adresa lui f: %p\n", f, &f);

    printf("Valoarea pointerului ptr_int: %p, Valoarea la adresa pointerului ptr_int: %d\n", ptr_int, *ptr_int);
    printf("Valoarea pointerului ptr_char: %p, Valoarea la adresa pointerului ptr_char: %c\n", ptr_char, *ptr_char);
    printf("Valoarea pointerului ptr_float: %p, Valoarea la adresa pointerului ptr_float: %f\n", ptr_float, *ptr_float);

    return 0;
}
