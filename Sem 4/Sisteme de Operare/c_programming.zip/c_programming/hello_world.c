#include <stdio.h>
// the program main entry point
//char stringVariable[] = "test string var";
int main(int argc, char** argv)
{
   printf("Hello world !\n")
   //printf("Hello world !%s\n",stringVariable);
   return 0;
}
